# Robovan Maliyet Simülatörü — ChatGPT için Yapım Dosyası

Bu dosyayı ChatGPT'ye (tercihen kod çalıştırabilen sohbet / Canvas) olduğu gibi yapıştırın ve şunu yazın:
**"Aşağıdaki şartnameye göre, tek dosyalık (HTML + CSS + JS) bir web sayfası yaz. Önce bölüm 9'daki doğrulama testlerini geçen hesap motorunu kur, sonra arayüzü yap."**

---

## 1. Amaç

Mikromobilite şirketi Tripy Mobility, L4 seviye otonom lojistik aracı **Robovan** almayı değerlendiriyor. Karar verici teknik değil. Sayfa, aynı işi yapan üç aracı karşılaştırır:

1. **Robovan** (sürücüsüz, uzaktan operatörlü, elektrikli)
2. **Dizel van** (sürücülü)
3. **Elektrikli van** (sürücülü)

Karşılaştırma ölçütleri: km, sefer ve ton-km başına maliyet; yıllık filo maliyeti; N yıllık toplam maliyet; geri ödeme (başa baş) süresi; başa baş sürücü maliyeti; gereken araç sayısı. **Her varsayım kullanıcı tarafından düzenlenebilir olmalı.** Sonuçlar girdi değiştikçe anında güncellenir.

İlham: Zelostech'in Z5 ürün sayfasındaki "Optimize Your Logistics Costs" hesaplayıcısı. Ondan fazlası istenir: üç araç, rota/harita, grafikler, duyarlılık analizi. Z5 referans özellikleri (üretici beyanı): menzil 230 km, yük 1.800 kg, hacim 6,2 m³, batarya 40,8 kWh.

Arayüz dili **Türkçe**. Sayı biçimi `tr-TR` (1.234,56). Kullanıcı terim olarak yaygın kelimeleri sever ("filtre", "dashboard" gibi); zorla Türkçeleştirme yapma.

## 2. Teknik kısıtlar

- **Tek dosya**: `index.html`, kütüphane gerektirmeyen saf JS. Tek istisna Mapbox GL JS (CDN, sürüm sabitle: `mapbox-gl@3.4.0`).
- Grafikler elle çizilen **SVG** (grafik kütüphanesi yok).
- Telefonda çalışmalı (400 px genişlikte yatay kaydırma olmamalı). Açık ve koyu tema (`prefers-color-scheme`).
- Para hesabında rakamlar JS `number`; ekranda yuvarlama yalnızca gösterimde.
- Ayarları `localStorage` ile sakla (try/catch ile; erişilemezse sayfa yine çalışmalı). **Mapbox anahtarı ayrı bir anahtarda** saklanır, sunucuya gönderilmez.
- Sunucu yok. Mapbox dışında hiçbir dış istek yapma.

## 3. Sayfa yapısı (yukarıdan aşağıya)

1. Başlık, para birimi seçici ($ / € / ₺, yalnız etiket), "Varsayılanlara dön", "Özeti kopyala".
2. Uyarı kutusu: "Örnek varsayımlar. Değerler gerçek teklif değildir; kendi rakamlarınızla değiştirin."
3. Uyarılar alanı (hesap sınırlarına çarpan durumlar, bölüm 6).
4. **Sonuç özeti** + "Karşılaştırma tabanı" seçici (Dizel van / Elektrikli van). KPI kartları, bölüm 7.
5. **Rota ve harita** (sol) ve **Operasyon senaryosu** (sağ). Dar ekranda alt alta.
6. **Araç varsayımları**: her araç için bir kart, gruplanmış açılır bölümler (`<details>`).
7. Grafikler: km başına maliyet (yığılı yatay çubuk), birikimli maliyet (çizgi), talebe duyarlılık (çizgi).
8. Ayrıntılı karşılaştırma tablosu.
9. "Nasıl hesaplanıyor" açıklama bölümü.

Renkler: Robovan turkuaz-yeşil, dizel turuncu-kahve, elektrikli van mavi. Maliyet kalemleri (enerji, bakım, personel, sermaye, sabit) ayrı beş renk. Başarı/uyarı/hata için yeşil/amber/kırmızı.

## 4. Girdiler ve örnek varsayılanlar

**Önemli:** Aşağıdaki sayılar yalnızca örnektir. Gerçek tedarikçi teklifi değildir. Sayfa bunu açıkça belirtmeli.

### 4.1 Senaryo (üç araca ortak)

| Alan | Varsayılan | Birim |
|---|---|---|
| Çalışma günü | 300 | gün/yıl |
| Günlük toplam sefer (tüm iş) | 8 | sefer/gün |
| Sefer başına durak | 4 | adet |
| Durak başına yükleme süresi | 10 | dk |
| Ortalama yük doluluğu | 70 | % |
| Sermaye maliyeti | 8 | %/yıl |
| Değerlendirme süresi | 5 | yıl |
| Robovan sayısını sabitle (0 = otomatik) | 0 | adet |
| Yol katsayısı (kuş uçuşu için) | 1,3 | × |
| Sefer türü | gidiş + dönüş | — |
| Mesafe kaynağı | rotadan | rota / elle |
| Elle tek yön mesafe | 4 | km |
| Varsayılan rota | Gebze → İzmit (Kocaeli) | — |

### 4.2 Araç şeması ve varsayılan değerler (JavaScript olarak, birebir kullan)

```js
var SCHEMA=[
{g:'Satın alma ve değer',f:[['price','Araç alış bedeli','cur'],['infra','Şarj / altyapı (araç başına)','cur'],['residual','Kalıntı değer','%'],['life','Ekonomik ömür','yıl'],['eng','Mühendislik + haritalama (filo toplamı, tek sefer)','cur','robo']]},
{g:'Enerji',f:[['l100','Yakıt tüketimi','L/100 km','ice'],['fuel','Yakıt fiyatı','cur/L','ice'],['kwh100','Elektrik tüketimi','kWh/100 km','ev,robo'],['elec','Elektrik fiyatı','cur/kWh','ev,robo'],['eff','Şarj verimi','%','ev,robo'],['chargeKw','Şarj gücü','kW','ev,robo'],['range','Menzil','km','ev,robo']]},
{g:'Bakım ve sabit giderler',f:[['maint','Bakım','cur/km'],['tire','Lastik','cur/km'],['ins','Sigorta','cur/yıl'],['tax','Vergi, muayene','cur/yıl'],['lic','Yazılım + bağlantı lisansı','cur/ay','robo']]},
{g:'Personel',f:[['driver','Sürücü maliyeti (işveren)','cur/ay','ice,ev'],['operator','Uzaktan operatör maliyeti','cur/ay','robo'],['ratio','Operatör başına araç','araç','robo'],['shiftH','Vardiya süresi','saat']]},
{g:'Kapasite ve hız',f:[['payload','Azami yük','kg'],['speed','Ortalama hız','km/sa'],['hours','Günlük çalışma süresi','saat/gün']]}
];
```

```js
var DEF={
cur:'$',days:300,demand:8,stops:4,loadMin:10,loadPct:70,rate:8,horizon:5,fleet:0,roadFactor:1.3,roundTrip:1,
mode:'route',manualKm:4,base:'ice',token:'',
wps:[{n:'Gebze',lat:40.8028,lon:29.4307},{n:'İzmit (Kocaeli)',lat:40.7654,lon:29.9408}],
v:{
 robo:{price:85000,infra:5000,residual:20,life:8,eng:15000,kwh100:18,elec:0.15,eff:90,chargeKw:22,range:230,maint:0.05,tire:0.01,ins:2500,tax:0,lic:250,operator:1800,ratio:5,shiftH:8,payload:1800,speed:40,hours:20},
 ice:{price:38000,infra:0,residual:25,life:8,l100:9,fuel:1.5,maint:0.08,tire:0.02,ins:2200,tax:500,driver:1500,shiftH:8,payload:1500,speed:45,hours:8},
 ev:{price:55000,infra:3000,residual:22,life:8,kwh100:20,elec:0.15,eff:90,chargeKw:11,range:200,maint:0.05,tire:0.02,ins:2300,tax:300,driver:1500,shiftH:8,payload:1200,speed:45,hours:8}
}};
var S=clone(DEF);
```

`kinds` sütunu (şemadaki 4. eleman) alanın hangi araçlarda görüneceğini belirler: `ice` yalnız dizel, `ev,robo` elektrikli ve robovan, `robo` yalnız robovan, boşsa hepsi.

## 5. Hesap motoru

Aşağıdaki kod **referans uygulamadır**. Formüller kesindir; değişken adlarını değiştirebilirsin ama sonuçlar bölüm 9'daki testlerle aynı çıkmalı. Yorumsuz bırakmadım, mantık şöyle:

1. **Sefer mesafesi** = tek yön × (gidiş-dönüşse 2).
2. **Sefer süresi** = yol süresi (mesafe/hız) + durak × yükleme dk / 60 + (elektrikli araçlarda) şarj süresi (sefer kWh / şarj gücü).
3. **Bir aracın günde yapabileceği azami sefer** = `max(1, floor(günlük çalışma saati / sefer süresi))`.
4. **Gereken araç sayısı** = `ceil(günlük toplam sefer / azami sefer)`. Robovan için sabitleme alanı doluysa o sayı kullanılır.
5. **Araç başına sefer** = toplam sefer / araç sayısı. **Vardiya sayısı** = `max(1, ceil(kullanılan saat / vardiya süresi))`.
6. **Yıllık km (araç)** = araç başına sefer × sefer mesafesi × çalışma günü.
7. **Enerji**: elektrikli için `km × kWh/100 / şarj verimi × elektrik fiyatı`; dizel için `km × L/100 × yakıt fiyatı`.
8. **Personel**: sürücülü araçta `aylık sürücü × 12 × vardiya`. Robovanda `aylık operatör × 12 × vardiya / operatör başına araç`.
9. **Sabit**: sigorta + vergi (+ robovanda lisans × 12).
10. **Sermaye**: yatırım = fiyat + altyapı (+ robovanda mühendislik/araç sayısı). Kalıntı değer = fiyat × kalıntı %. Amortisman doğrusal `(yatırım − kalıntı)/ömür`. Finansman = `(yatırım + kalıntı)/2 × oran`.
11. **Yıllık toplam** = enerji + bakım/lastik + sabit + personel + amortisman + finansman. **Nakit işletme** = amortisman ve finansman hariç.
12. **Birimler**: km başına, sefer başına, ton-km başına (`km × yük kg/1000 × doluluk`).
13. **Birikimli maliyet(t)** = araç sayısı × (yatırım + nakit işletme × t). **Toplam maliyet(t)** = bunun üstünden kalıntı değer düşülür (kalıntı, ömür boyunca doğrusal azalır).
14. **Başa baş (robovan vs taban)**: `t = (A0 − B0) / (B1 − A1)`, A robovan; 0 = yatırım, 1 = yıllık nakit işletme. Robovan her ikisinde de ucuzsa "İlk günden ucuz"; yıllık işletmesi daha pahalıysa "Geri ödemez".
14b. **Başa baş sürücü maliyeti**: taban aracın aylık sürücü maliyeti değişirken yıllık filo maliyeti robovanınkine eşit olduğu değer (ikiye bölme, 0–60.000 aralığı). 0'da bile taban pahalıysa "Robovan her maaşta daha ucuz"; üst sınırda bile ucuzsa "60.000 üzerinde".

```js
function hav(a,b){var R=6371,r=Math.PI/180,dLa=(b.lat-a.lat)*r,dLo=(b.lon-a.lon)*r;
 var x=Math.sin(dLa/2)*Math.sin(dLa/2)+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(dLo/2)*Math.sin(dLo/2);return 2*R*Math.asin(Math.sqrt(x))}
function airKm(){var t=0;for(var i=1;i<S.wps.length;i++)t+=hav(S.wps[i-1],S.wps[i]);return t}
function routeInfo(){
 if(S.mode==='manual')return {km:Math.max(0,S.manualKm),src:'Elle girilen mesafe'};
 if(S.wps.length<2)return {km:0,src:'En az 2 durak gerekli'};
 if(mb.routeKm!=null)return {km:mb.routeKm,src:'Mapbox karayolu'};
 return {km:airKm()*S.roadFactor,src:'Kuş uçuşu × '+num(S.roadFactor,2)};
}

/* ---------- hesap motoru ---------- */
function calc(kind,vc,D,rt,fleetOverride){
 var tripKm=rt.km*(S.roundTrip?2:1);
 var isEv=kind!=='ice';
 var driveH=vc.speed>0?tripKm/vc.speed:0;
 var loadH=S.stops*S.loadMin/60;
 var tripKwh=isEv?tripKm*vc.kwh100/100:0;
 var chargeH=isEv&&vc.chargeKw>0?tripKwh/vc.chargeKw:0;
 var tripH=Math.max(driveH+loadH+chargeH,0.01);
 var overtime=tripH>vc.hours;
 var maxTrips=Math.max(1,Math.floor(vc.hours/tripH+1e-9));
 var n=fleetOverride>0?fleetOverride:Math.max(1,Math.ceil(D/maxTrips-1e-9));
 var tpv=D/n;
 var usedH=tpv*tripH;
 var shifts=Math.max(1,Math.ceil(usedH/Math.max(vc.shiftH,1)-1e-9));
 var kmv=tpv*tripKm*S.days;
 var energy=isEv?kmv*vc.kwh100/100/Math.max(vc.eff/100,0.01)*vc.elec:kmv*vc.l100/100*vc.fuel;
 var maint=kmv*(vc.maint+vc.tire);
 var fixed=vc.ins+vc.tax+(kind==='robo'?vc.lic*12:0);
 var people=kind==='robo'?vc.operator*12*shifts/Math.max(vc.ratio,1):vc.driver*12*shifts;
 var eng=kind==='robo'?vc.eng/n:0;
 var capex=vc.price+vc.infra+eng;
 var resV=vc.price*vc.residual/100;
 var dep=(capex-resV)/Math.max(vc.life,1);
 var fin=(capex+resV)/2*S.rate/100;
 var cashOpex=energy+maint+fixed+people;
 var total=cashOpex+dep+fin;
 var perKm=kmv>0?total/kmv:NaN;
 var trips=tpv*S.days;
 var tonkm=kmv*vc.payload/1000*S.loadPct/100;
 return {kind:kind,n:n,tpv:tpv,tripKm:tripKm,tripH:tripH,usedH:usedH,shifts:shifts,maxTrips:maxTrips,overtime:overtime,
  rangeFail:isEv&&tripKm>vc.range*0.95,kmv:kmv,energy:energy,maint:maint,fixed:fixed,people:people,dep:dep,fin:fin,
  cashOpex:cashOpex,total:total,fleet:total*n,perKm:perKm,perTrip:trips>0?total/trips:NaN,perTonKm:tonkm>0?total/tonkm:NaN,
  capex:capex,capexFleet:capex*n,resV:resV,life:vc.life,price:vc.price,
  cum:function(t){return n*(capex+cashOpex*t)},
  tco:function(t){var r=resV+(vc.price-resV)*(1-Math.min(t,vc.life)/Math.max(vc.life,1));return n*(capex+cashOpex*t)-n*r}};
}
function all(D,rt,fo){var o={};['robo','ice','ev'].forEach(function(k){o[k]=calc(k,S.v[k],D,rt,k==='robo'?fo:0)});return o}
function breakEven(a,b){ /* a: robovan, b: taban */
 var a0=a.capexFleet,a1=a.n*a.cashOpex,b0=b.capexFleet,b1=b.n*b.cashOpex;
 if(a0<=b0&&a1<=b1)return {t:0,txt:'İlk günden ucuz',ok:true};
 if(a1>=b1)return {t:Infinity,txt:'Geri ödemez',ok:false};
 if(a0<=b0)return {t:0,txt:'İlk günden ucuz',ok:true};
 var t=(a0-b0)/(b1-a1);return {t:t,txt:num(t,1)+' yıl',ok:true};
}
function breakEvenWage(rt){
 var robo=calc('robo',S.v.robo,S.demand,rt,S.fleet);
 var k=S.base;var orig=S.v[k].driver;
 function f(w){S.v[k].driver=w;var c=calc(k,S.v[k],S.demand,rt,0);return c.fleet-robo.fleet}
 var r;var lo=0,hi=60000;
 if(f(0)>0)r={v:0,txt:'Robovan her maaşta daha ucuz'};
 else if(f(hi)<0)r={v:Infinity,txt:'60.000 üzerinde'};
 else{for(var i=0;i<50;i++){var m=(lo+hi)/2;if(f(m)>0)hi=m;else lo=m}r={v:(lo+hi)/2,txt:null}}
 S.v[k].driver=orig;return r;
}
```

> Not: `S` global durum nesnesidir (bölüm 4.1 alanları + `v` altında üç araç). `routeInfo()` bölüm 8'deki rota kaynağını döndürür.

## 6. Uyarılar (kullanıcıya gösterilecek)

- Rota modunda 2'den az durak: "Rota için en az iki durak gerekli."
- Tek sefer, günlük çalışma süresini aşıyorsa: ilgili araç için uyar (sonuç sefer başına bir araç varsayar).
- Elektrikli araçta tek sefer menzilin %95'ini aşıyorsa: ek şarj gerekebileceğini söyle.
- Kalıcı bilgi notu: **Şartnameye göre robovan yalnızca trafiğe kapalı, kontrollü alanlarda çalışır.** Şehirler arası rotalar karşılaştırma içindir.

## 7. KPI kartları (sırayla)

1. km başına maliyet (robovan; altında taban ve % fark; ana kart, vurgulu)
2. Yıllık filo maliyeti (robovan, taban)
3. Yıllık fark (+ robovan lehine / − aleyhine)
4. N yıllık toplam maliyet farkı (kalıntı değer düşülmüş)
5. Başa baş (geri ödeme) + ilk yatırım farkı
6. Başa baş sürücü maliyeti
7. Gereken araç sayısı (robovan · dizel · elektrikli)

## 8. Rota ve Mapbox

Durak listesi ortak veri yapısıdır: `{n: ad, lat, lon}`. Üç ekleme yolu:

- **Şehir listesi** (aşağıda) + "Şehri durak olarak ekle" ve hazır rota düğmeleri (Gebze→İzmit, İstanbul→Bursa, İstanbul→Ankara, Ankara→Eskişehir).
- **Adres arama** (Mapbox Geocoding v6): `GET https://api.mapbox.com/search/geocode/v6/forward?q=...&limit=5&language=tr&access_token=...` → `features[].properties.full_address` ve `geometry.coordinates [lon,lat]`.
- **Haritaya tıklama**: tıklanan nokta eklenir, adı Geocoding v6 `reverse` ile sessizce güncellenir.

Mesafe kaynağı önceliği:
1. Kullanıcı "Mesafeyi elle gir"i seçtiyse elle değer.
2. Mapbox hazır ve ≥2 durak varsa **Directions API**: `GET https://api.mapbox.com/directions/v5/mapbox/driving/{lon,lat;lon,lat}?geometries=geojson&overview=full&access_token=...` → `routes[0].distance` (m) ve `geometry` (haritaya çizgi olarak çiz). Eski istek geç dönerse yok say (sıra numarası).
3. Aksi halde Haversine kuş uçuşu toplamı × yol katsayısı.

Mapbox başlatma: kullanıcı anahtar kutusuna `pk.` anahtarını yazar, "Haritayı başlat"a basar. Stil `mapbox://styles/mapbox/streets-v12`. Anahtar geçersizse (401) ve ağ hatasında harita alanında Türkçe, açıklayıcı hata göster; hesap şehir listesiyle çalışmaya devam eder. Anahtarı ve adres/rota koordinatlarını Mapbox dışında hiçbir yere gönderme. Mapbox CSS'ini (`mapbox-gl.css`) sayfaya ekle.

Şehirler (ad, enlem, boylam): Gebze 40.8028, 29.4307 · İzmit (Kocaeli) 40.7654, 29.9408 · İstanbul 41.0082, 28.9784 · Ankara 39.9334, 32.8597 · İzmir 38.4237, 27.1428 · Bursa 40.1885, 29.0610 · Antalya 36.8969, 30.7133 · Adana 37.0, 35.3213 · Konya 37.8746, 32.4932 · Gaziantep 37.0662, 37.3833 · Eskişehir 39.7767, 30.5206 · Kayseri 38.7312, 35.4787 · Samsun 41.2867, 36.33 · Trabzon 41.0027, 39.7168 · Mersin 36.8121, 34.6415 · Diyarbakır 37.9144, 40.2306 · Tekirdağ 40.9833, 27.5167 · Sakarya 40.7569, 30.3783 · Edirne 41.6771, 26.5557 · Denizli 37.7765, 29.0864 · Muğla 37.2153, 28.3636 · Berlin 52.52, 13.405 · Münih 48.1351, 11.582 · Frankfurt 50.1109, 8.6821 · Dubai 25.2048, 55.2708.

## 9. Doğrulama testleri (kodu yazınca çalıştır, sonucu raporla)

Tüm varsayılanlarla (bölüm 4) ve para birimi $ iken. Rota Gebze→İzmit, Haversine × 1,3 ≈ 56,09 km tek yön, gidiş-dönüş ≈ 112,19 km. Para tutarlarında kabul toleransı ±%1; km başına maliyet 2 ondalığa yuvarlanmış halde karşılaştırılır (ham değer 0,3359 → 0,34).

| Çıktı | Robovan | Dizel van | Elektrikli van |
|---|---|---|---|
| Gereken araç | 2 | 4 | 8 |
| km başına maliyet (2 hane) | 0,34 $ | 0,62 $ | 0,97 $ |
| Yıllık filo maliyeti | ≈ 90.437 $ | ≈ 167.923 $ | ≈ 260.954 $ |
| Sefer süresi | ≈ 4,39 sa | ≈ 3,16 sa | ≈ 5,20 sa |

Robovanın dizele göre geri ödemesi ≈ 0,5 yıl; ilk yatırım farkı ≈ 43.000 $; "başa baş sürücü maliyeti" = "Robovan her maaşta daha ucuz".

Ek testler:
- "Günlük toplam sefer"i 1 yaparsan her araç türünde 1 araç çıkmalı.
- Elle mesafe 4 km, tek yön, gidiş-dönüş: sefer mesafesi 8 km olmalı.
- Sürücü maliyetini 0 yaparsan dizel vanın personel kalemi 0 olmalı.
- Robovan sayısını sabitlersen yalnız robovan etkilenmeli.
- Tüm alanlar boş/0 girilirse sayfa hata vermemeli ("—" göstermeli, `NaN`/`Infinity` göstermemeli).

## 10. Grafik kuralları

- **km başına maliyet**: üç satır, her satır beş kalemden oluşan yığılı çubuk, sonda toplam değer. Kalemler: Enerji, Bakım + lastik, Personel, Amortisman + finansman, Sigorta/vergi/lisans.
- **Birikimli maliyet**: 0–10 yıl, üç çizgi, robovanın diğer ikisiyle başa baş noktaları daire ile işaretli, değerlendirme süresi kesik dikey çizgi.
- **Duyarlılık**: x ekseni günlük toplam sefer (1–40), y ekseni km başına maliyet; mevcut senaryo kesik dikey çizgi. Araç sayısı tam sayıya yukarı yuvarlandığı için çizgi testere dişi gibi inebilir; bu beklenen davranıştır, düzleştirme.
- Eksen değerleri "bin", "mn" gibi kısaltılabilir. Grafik metinleri tema rengini kullanmalı. Her çubuk/nokta `<title>` ile değer ipucu vermeli.

## 11. Kalite ve davranış

- Kullanıcı bir alanı değiştirince tüm sonuçlar anında güncellenmeli; alan odağını kaybetmemeli (formu yeniden çizme, yalnız sonuçları çiz).
- Sayı girişinde virgül ve nokta kabul edilir. Boş alan 0 sayılır.
- "Özeti kopyala": rota, araç sayıları, km maliyetleri, yıllık filo maliyeti ve başa baş bilgisini düz metin olarak panoya kopyalar; pano erişimi reddedilirse `execCommand('copy')` ile dener.
- Klavye odağı görünür olmalı; düğmeler en az 38 px yükseklikte.
- Para birimi yalnız **etikettir**; dönüşüm yapmaz. Bunu sayfada belirt.
- Hiçbir yerde kesin tasarruf vaadi yazma. Sonuçlar "bu varsayımlarla" ifadesiyle sunulur.

## 12. Bu dosyayı teslim ederken ChatGPT'den istenenler

1. Tek bir `index.html` dosyası ver.
2. Bölüm 9 testlerini çalıştırıp sonucu tablo olarak göster. Çalıştıramıyorsan "çalıştıramadım" de.
3. Mapbox kısmını gerçek anahtarla test edemediysen bunu açıkça belirt.
4. Varsayılan değerlerin örnek olduğunu sayfada ve cevabında belirt.
5. Bu dosyada olmayan özellik ekleme (kullanıcı hesabı, sunucu, veritabanı, otomatik kur).

## Ek: Çalışan referans sayfa

Aynı mantığın tamamen çalışan hali `Robovan-Maliyet-Simulatoru.html` dosyasıdır (Claude tarafından yazıldı). ChatGPT'ye bu `.md` dosyasıyla birlikte onu da yükleyip "arayüzü bu dosyadaki gibi yap, ama bölüm 9 testlerini kendin de doğrula" diyebilirsiniz.

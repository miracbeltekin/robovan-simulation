'use strict';
/* Rastgele geçerli yapılandırmalar için motor çıktısını JSON olarak yazar (bağımsız Python doğrulaması için). */
const E = require('../src');
let s = 12345; const R = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; const u = (a, b) => a + (b - a) * R();
const out = [];
for (let i = 0; i < 400; i++) {
  const c = E.defaultConfig();
  Object.assign(c.scenario, { demand: Math.floor(u(1, 50)), days: Math.floor(u(100, 366)), stops: Math.floor(u(0, 12)), loadMin: u(0, 40), loadPct: u(10, 100), rate: u(0, 20), horizon: u(1, 10), fleet: R() > 0.8 ? Math.floor(u(1, 12)) : 0, roadFactor: u(1, 1.8), roundTrip: R() > 0.4 });
  c.route.mode = 'manual'; c.route.manualKm = u(1, 150); c.base = R() > 0.5 ? 'ice' : 'ev';
  for (const k of ['robo', 'ice', 'ev']) for (const f of Object.keys(c.vehicles[k])) c.vehicles[k][f] *= u(0.5, 1.8);
  for (const k of ['robo', 'ice', 'ev']) { const v = c.vehicles[k]; v.residual = Math.min(v.residual, 90); v.eff = Math.min(100, v.eff); v.hours = Math.min(24, v.hours); v.shiftH = Math.min(24, v.shiftH); v.life = Math.max(1, v.life); }
  const r = E.analyze(c); if (!r.ok) continue;
  const o = { cfg: c, res: {} };
  for (const k of ['robo', 'ice', 'ev']) { const v = r.vehicles[k]; o.res[k] = { n: v.n, tripH: v.tripH, kmv: v.kmv, energy: v.energy, maint: v.maint, fixed: v.fixed, people: v.people, dep: v.dep, fin: v.fin, total: v.total, fleet: v.fleet, perKm: v.perKm, perTrip: v.perTrip, perTonKm: v.perTonKm, tco: v.tco(c.scenario.horizon), cum5: v.cumulative(5), staff: v.ops.staff, energyQty: v.ops.energyQty }; }
  o.kpi = { saving: r.kpi.annualSaving, be: r.kpi.breakEven.years, tcoSaving: r.kpi.tcoSaving, base: c.base };
  out.push(o);
}
console.log(JSON.stringify(out));

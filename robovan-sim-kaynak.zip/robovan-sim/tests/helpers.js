'use strict';
const fs = require('fs'), path = require('path');
const FIX = (n) => fs.readFileSync(path.join(__dirname, 'fixtures', n), 'utf8');
const OSRM = FIX('osrm-gebze-izmit.json'), PHOTON = FIX('photon-gebze.json');
const CORS = { 'access-control-allow-origin': '*' };
const ALLOWED = ['tiles.openfreemap.org', 'router.project-osrm.org', 'routing.openstreetmap.de', 'photon.komoot.io'];
const isExt = (u) => !u.startsWith('file:') && !u.startsWith('data:') && !u.startsWith('blob:') && !/^https?:\/\/(localhost|127\.0\.0\.1)/.test(u);
/* Rota ve adres servisleri: gerçek OSRM/Photon yanıtları (önceden alındı) ile beslenir. Harita karoları GERÇEK OpenFreeMap'ten gelir. */
async function stubServices(ctx, st = {}) {
  st.osrm = []; st.fossgis = []; st.photon = []; st.mode = st.mode || 'ok';
  await ctx.route(/router\.project-osrm\.org\/route/, (r) => { st.osrm.push({ t: Date.now(), url: r.request().url() }); if (st.mode === 'osrm-down' || st.mode === 'all-down') return r.abort('failed'); r.fulfill({ contentType: 'application/json', headers: CORS, body: OSRM }); });
  await ctx.route(/routing\.openstreetmap\.de\/routed-car\/route/, (r) => { st.fossgis.push({ t: Date.now(), url: r.request().url() }); if (st.mode === 'all-down') return r.abort('failed'); r.fulfill({ contentType: 'application/json', headers: CORS, body: OSRM }); });
  await ctx.route(/photon\.komoot\.io\/api/, (r) => { st.photon.push({ t: Date.now(), url: r.request().url() }); if (st.mode === 'all-down') return r.abort('failed'); r.fulfill({ contentType: 'application/json', headers: CORS, body: PHOTON }); });
  return st;
}
async function blockAllExternal(ctx, seen = []) { await ctx.route('**/*', (r) => { const u = r.request().url(); if (isExt(u)) { try { seen.push(new URL(u).host); } catch (e) {} return r.abort('failed'); } r.continue(); }); return seen; }
async function waitMap(p, state = 'ready', ms = 45000) { await p.waitForFunction((s) => window.RobovanMap && window.RobovanMap.debug().state === s, state, { timeout: ms }); }
async function waitPlan(p, ms = 20000) { await p.waitForFunction(() => !document.getElementById('pp').disabled, null, { timeout: ms }); }
const ARGS = ['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist', '--enable-unsafe-swiftshader'];
module.exports = { stubServices, blockAllExternal, waitMap, waitPlan, ARGS, ALLOWED, isExt, OSRM, PHOTON };

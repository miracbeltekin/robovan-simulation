'use strict';
/* Bağımlılıksız test koşucusu: node tests/run.js [engine yolu]. Çıkış kodu: 0 hepsi geçti, 1 kaldı. */
const path = require('path');
const E = require(path.resolve(process.argv[2] || path.join(__dirname, '../src/index.js')));

const rows = [];
let fail = 0;
const fmt = (x) => (typeof x === 'number' ? (Number.isInteger(x) ? String(x) : x.toFixed(4)) : String(x));
function record(group, name, expected, actual, pass) {
  rows.push({ group, name, expected, actual, pass });
  if (!pass) fail++;
}
const near = (a, b, tolPct) => Math.abs(a - b) <= Math.abs(b) * tolPct / 100;
function eqRel(group, name, expected, actual, tolPct) { record(group, name, '≈ ' + fmt(expected) + ` (±%${tolPct})`, fmt(actual), near(actual, expected, tolPct)); }
function eq(group, name, expected, actual) { record(group, name, fmt(expected), fmt(actual), expected === actual); }
function truthy(group, name, cond, note) { record(group, name, 'doğru', cond ? 'doğru' : 'YANLIŞ' + (note ? ' — ' + note : ''), !!cond); }

const base = () => E.defaultConfig();
const r0 = E.analyze(base());
const V = r0.vehicles;

/* ===== A. Şartname bölüm 9: ana tablo ===== */
const G9 = 'Şartname 9';
truthy(G9, 'Varsayılan analiz geçerli', r0.ok, (r0.errors || []).join('; '));
eqRel(G9, 'Rota tek yön km (≈57)', 57, r0.route.km, 2);
eq(G9, 'Gereken araç · Robovan', 2, V.robo.n); eq(G9, 'Gereken araç · Dizel', 4, V.ice.n); eq(G9, 'Gereken araç · Elektrikli', 8, V.ev.n);
eq(G9, 'km maliyeti 2 hane · Robovan', 0.34, +V.robo.perKm.toFixed(2));
eq(G9, 'km maliyeti 2 hane · Dizel', 0.62, +V.ice.perKm.toFixed(2));
eq(G9, 'km maliyeti 2 hane · Elektrikli', 0.97, +V.ev.perKm.toFixed(2));
eqRel(G9, 'Yıllık filo · Robovan', 90437, V.robo.fleet, 1); eqRel(G9, 'Yıllık filo · Dizel', 167923, V.ice.fleet, 1); eqRel(G9, 'Yıllık filo · Elektrikli', 260954, V.ev.fleet, 1);
eqRel(G9, 'Sefer süresi · Robovan (sa)', 4.39, V.robo.tripH, 1); eqRel(G9, 'Sefer süresi · Dizel (sa)', 3.16, V.ice.tripH, 1); eqRel(G9, 'Sefer süresi · Elektrikli (sa)', 5.20, V.ev.tripH, 1);
eqRel(G9, 'Geri ödeme (yıl, ≈0,5)', 0.5, r0.kpi.breakEven.years, 5);
eqRel(G9, 'İlk yatırım farkı', 43000, r0.kpi.investmentDiff, 1);
eq(G9, 'Başa baş sürücü maliyeti', 'always', r0.kpi.breakEvenWage.status);
/* şartnamedeki "±%1" ifadesi 0,34 için tutmaz (gerçek 0,3359 → %1,2 sapma): gerçek değer 2 hanede 0,34 */
eqRel(G9, 'km maliyeti ham · Robovan (şartname ±%1 okuması)', 0.34, V.robo.perKm, 1.5);

/* ===== B. Şartname bölüm 9: ek testler ===== */
const GB = 'Şartname 9 ek';
{ const c = base(); c.scenario.demand = 1; const r = E.analyze(c); eq(GB, 'Talep=1 → her türde 1 araç', '1,1,1', [r.vehicles.robo.n, r.vehicles.ice.n, r.vehicles.ev.n].join(',')); }
{ const c = base(); c.route.mode = 'manual'; c.route.manualKm = 4; const r = E.analyze(c); eq(GB, 'Elle 4 km, gidiş-dönüş → sefer 8 km', 8, r.vehicles.robo.tripKm); }
{ const c = base(); c.vehicles.ice.driver = 0; const r = E.analyze(c); eq(GB, 'Sürücü 0 → dizel personel 0', 0, r.vehicles.ice.people); }
{ const c = base(); c.scenario.fleet = 5; const r = E.analyze(c);
  eq(GB, 'Robovan sabitleme → robovan 5 araç', 5, r.vehicles.robo.n);
  eq(GB, 'Sabitleme dizeli etkilemez', V.ice.fleet, r.vehicles.ice.fleet); eq(GB, 'Sabitleme elektrikliyi etkilemez', V.ev.fleet, r.vehicles.ev.fleet); }
{ const c = base(); Object.keys(c.scenario).forEach((k) => { if (typeof c.scenario[k] === 'number') c.scenario[k] = 0; }); ['robo', 'ice', 'ev'].forEach((k) => Object.keys(c.vehicles[k]).forEach((f) => { c.vehicles[k][f] = 0; }));
  const r = E.analyze(c); truthy(GB, 'Her alan 0 → hata listesi, çökme yok', r.ok === false && r.errors.length > 0);
  truthy(GB, 'Her alan 0 → çıktıda NaN/Infinity yok', !JSON.stringify(r).match(/NaN|Infinity/)); }
{ const c = base(); ['robo', 'ice', 'ev'].forEach((k) => Object.keys(c.vehicles[k]).forEach((f) => { c.vehicles[k][f] = ''; }));
  const r = E.analyze(c); truthy(GB, 'Boş metin alanlar → ok:false', r.ok === false); }

/* ===== C. Geometri ===== */
const GC = 'Geometri';
{ const ist = { lat: 41.0082, lon: 28.9784 }, ank = { lat: 39.9334, lon: 32.8597 };
  eqRel(GC, 'İstanbul–Ankara kuş uçuşu (≈350 km)', 350, E.haversineKm(ist, ank), 1.5);
  eq(GC, 'Aynı nokta → 0', 0, E.haversineKm(ist, ist));
  eq(GC, 'Simetri', E.haversineKm(ist, ank), E.haversineKm(ank, ist));
  eqRel(GC, 'Antipod (≈20015 km)', 20015, E.haversineKm({ lat: 0, lon: 0 }, { lat: 0, lon: 180 }), 0.1);
  let threw = false; try { E.haversineKm({ lat: 95, lon: 0 }, ist); } catch (e) { threw = e instanceof RangeError; }
  truthy(GC, 'Geçersiz enlem → RangeError', threw); }
{ const rt = E.routeDistance({ mode: 'route', waypoints: [{ n: 'a', lat: 40, lon: 29 }] }, 1.3);
  truthy(GC, 'Tek durak → hata mesajı', rt.errors.length === 1 && rt.km === 0); }
{ const rt = E.routeDistance({ mode: 'manual', manualKm: -1 }, 1.3); truthy(GC, 'Negatif elle mesafe → hata', rt.errors.length === 1); }
{ const rt = E.routeDistance({ mode: 'route', waypoints: [{ lat: 0, lon: 0 }, { lat: 0, lon: 1 }] }, 1.3, 77); eq(GC, 'Gerçek yol mesafesi varsa önceliklidir', 77, rt.km); }

/* ===== D. Doğrulama ===== */
const GD = 'Doğrulama';
function bad(name, mut) { const c = base(); mut(c); const r = E.analyze(c); truthy(GD, name, r.ok === false && r.errors.length > 0 && !JSON.stringify(r).match(/NaN|Infinity/), JSON.stringify(r.errors)); }
bad('Hız 0 reddedilir', (c) => { c.vehicles.robo.speed = 0; });
bad('Şarj gücü 0 reddedilir', (c) => { c.vehicles.ev.chargeKw = 0; });
bad('Ömür 0 reddedilir', (c) => { c.vehicles.ice.life = 0; });
bad('Operatör başına araç 0 reddedilir', (c) => { c.vehicles.robo.ratio = 0; });
bad('Verim 0 reddedilir', (c) => { c.vehicles.ev.eff = 0; });
bad('Kalıntı %101 reddedilir', (c) => { c.vehicles.ice.residual = 101; });
bad('Negatif fiyat reddedilir', (c) => { c.vehicles.ice.price = -1; });
bad('NaN reddedilir', (c) => { c.vehicles.ice.fuel = NaN; });
bad('Infinity reddedilir', (c) => { c.vehicles.ice.fuel = Infinity; });
bad('Metin sayı reddedilir', (c) => { c.vehicles.ice.fuel = '1,5'; });
bad('Null reddedilir', (c) => { c.vehicles.ev.range = null; });
bad('Çalışma günü 0 reddedilir', (c) => { c.scenario.days = 0; });
bad('Yük doluluğu 101 reddedilir', (c) => { c.scenario.loadPct = 101; });
bad('Robovan sayısı ondalık reddedilir', (c) => { c.scenario.fleet = 2.5; });
bad('Yol katsayısı 0,9 reddedilir', (c) => { c.scenario.roadFactor = 0.9; });
bad('Geçersiz taban reddedilir', (c) => { c.base = 'x'; });
bad('Araç bilgisi eksik reddedilir', (c) => { delete c.vehicles.ev; });
bad('Rota 1 durak reddedilir', (c) => { c.route.waypoints = c.route.waypoints.slice(0, 1); });
bad('Rota koordinatı bozuk reddedilir', (c) => { c.route.waypoints[0].lat = 'x'; });
{ let ok = true, res; try { res = E.analyze(null); } catch (e) { ok = false; } truthy(GD, 'null yapılandırma çökmez, ok:false döner', ok && res && res.ok === false); }

/* ===== E. Hesap kimlikleri ve sınır durumları ===== */
const GE = 'Hesap kimlikleri';
['robo', 'ice', 'ev'].forEach((k) => {
  const c = V[k];
  eqRel(GE, `${k}: toplam = kalemlerin toplamı`, c.energy + c.maint + c.fixed + c.people + c.dep + c.fin, c.total, 0.0001);
  eqRel(GE, `${k}: filo = toplam × araç`, c.total * c.n, c.fleet, 0.0001);
  eqRel(GE, `${k}: birikimli(0) = ilk yatırım (filo)`, c.capexFleet, c.cumulative(0), 0.0001);
  eqRel(GE, `${k}: km başına × km = toplam`, c.total, c.perKm * c.kmv, 0.0001);
  truthy(GE, `${k}: TCO(ömür) = filo yatırımı + işletme − kalıntı`, near(c.tco(c.life), c.n * (c.capex + c.cashOpex * c.life - c.resV), 0.0001));
});
{ const b = E.breakEven({ capexFleet: 200, n: 1, cashOpex: 10 }, { capexFleet: 100, n: 1, cashOpex: 60 }); eqRel(GE, 'Başa baş formülü (100/50 = 2 yıl)', 2, b.years, 0.001); eq(GE, 'Başa baş durumu', 'payback', b.status); }
{ const b = E.breakEven({ capexFleet: 50, n: 1, cashOpex: 10 }, { capexFleet: 100, n: 1, cashOpex: 60 }); eq(GE, 'Her iki yönde ucuz → hemen', 'immediate', b.status); }
{ const b = E.breakEven({ capexFleet: 200, n: 1, cashOpex: 70 }, { capexFleet: 100, n: 1, cashOpex: 60 }); eq(GE, 'İşletme daha pahalı → geri ödemez', 'never', b.status); }
{ const c = base(); c.vehicles.ice.driver = 0; const r = E.analyze(c);
  c.vehicles.ice.driver = 1500; c.vehicles.robo.operator = 20000; const r2 = E.analyze(c);
  truthy(GE, 'Pahalı operatörde başa baş sürücü maliyeti bulunur (found)', r2.kpi.breakEvenWage.status === 'found' && r2.kpi.breakEvenWage.value > 1500, JSON.stringify(r2.kpi.breakEvenWage));
  if (r2.kpi.breakEvenWage.status === 'found') { const c3 = base(); c3.vehicles.robo.operator = 20000; c3.vehicles.ice.driver = r2.kpi.breakEvenWage.value; const r3 = E.analyze(c3); eqRel(GE, 'Bulunan maaşta iki filo maliyeti eşit', r3.vehicles.robo.fleet, r3.vehicles.ice.fleet, 0.01); } }
{ const c = base(); c.scenario.demand = 0; const r = E.analyze(c); truthy(GE, 'Talep 0 → ok, km maliyeti null (NaN değil)', r.ok && r.vehicles.robo.perKm === null && !JSON.stringify(r).match(/NaN|Infinity/)); }
{ const c = base(); c.route.mode = 'manual'; c.route.manualKm = 0; const r = E.analyze(c); truthy(GE, 'Mesafe 0 → ok, km maliyeti null, uyarı var', r.ok && r.vehicles.ice.perKm === null && r.warnings.some((w) => w.includes('0 km'))); }
{ const c = base(); c.route.mode = 'manual'; c.route.manualKm = 400; c.scenario.demand = 2; const r = E.analyze(c);
  truthy(GE, 'Çok uzun sefer → mesai aşımı uyarısı', r.warnings.some((w) => w.includes('günlük çalışma süresini aşıyor')));
  truthy(GE, 'Çok uzun sefer → menzil uyarısı', r.warnings.some((w) => w.includes('menzile'))); }
{ const c = base(); c.scenario.fleet = 1; const r = E.analyze(c); truthy(GE, 'Yetersiz sabit araç → kapasite uyarısı', r.warnings.some((w) => w.includes('yetmiyor'))); }
{ const c = base(); c.scenario.roundTrip = false; const r = E.analyze(c); eqRel(GE, 'Tek yön → sefer mesafesi = rota', r.route.km, r.vehicles.robo.tripKm, 0.0001); }
{ const c = base(); c.scenario.rate = 0; const r = E.analyze(c); eq(GE, 'Sermaye maliyeti 0 → finansman 0', 0, r.vehicles.ice.fin); }
{ const c = base(); c.vehicles.ice.residual = 100; const r = E.analyze(c); eq(GE, 'Kalıntı %100 → amortisman 0 (altyapı yok)', 0, r.vehicles.ice.dep); }
{ const rows2 = E.sensitivity(base(), 20.0 * 0 + 57, 40); eq(GE, 'Duyarlılık 40 satır', 40, rows2.length); truthy(GE, 'Duyarlılık değerleri sonlu', rows2.every((x) => Number.isFinite(x.robo) && Number.isFinite(x.ice) && Number.isFinite(x.ev))); }
{ const a = JSON.stringify(E.analyze(base()).vehicles.robo.fleet), b = JSON.stringify(E.analyze(base()).vehicles.robo.fleet); eq(GE, 'Aynı girdi, aynı sonuç', a, b); }
{ const c = base(); const before = JSON.stringify(c); E.analyze(c); eq(GE, 'Girdi nesnesi değiştirilmez', before, JSON.stringify(c)); }
{ const c = base(); const r1 = E.analyze(c); c.vehicles.robo.price = 1; const r2 = E.analyze(base()); eq(GE, 'Önceki çağrı sonraki çağrıyı etkilemez', r1.vehicles.robo.fleet, r2.vehicles.robo.fleet); }
/* Monotonluk: sürücü maliyeti arttıkça dizel filo maliyeti azalmaz */
{ let prev = -1, ok = true; for (let w = 0; w <= 8000; w += 500) { const c = base(); c.vehicles.ice.driver = w; const f = E.analyze(c).vehicles.ice.fleet; if (f < prev) ok = false; prev = f; } truthy(GE, 'Sürücü maliyeti ↑ → dizel filo maliyeti ↓ olmaz', ok); }

/* ===== F. Rastgele test (tohumlu): geçerli girdide çökme/NaN yok ===== */
const GF = 'Rastgele test';
function rng(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
{ const R = rng(20260101); const u = (a, b) => a + (b - a) * R();
  let bad1 = 0, thrown = 0, okCount = 0;
  for (let i = 0; i < 3000; i++) {
    const c = base();
    c.scenario.demand = Math.floor(u(0, 60)); c.scenario.days = Math.floor(u(1, 366)); c.scenario.stops = Math.floor(u(0, 30)); c.scenario.loadMin = u(0, 60);
    c.scenario.loadPct = u(0, 100); c.scenario.rate = u(0, 30); c.scenario.horizon = u(0, 20); c.scenario.fleet = Math.floor(u(0, 30)); c.scenario.roadFactor = u(1, 2); c.scenario.roundTrip = R() > 0.5;
    c.route.mode = 'manual'; c.route.manualKm = u(0, 800); c.base = R() > 0.5 ? 'ice' : 'ev';
    ['robo', 'ice', 'ev'].forEach((k) => { const v = c.vehicles[k]; Object.keys(v).forEach((f) => { v[f] = v[f] * u(0.3, 2.5); });
      v.residual = Math.min(100, v.residual); v.eff = Math.min(100, Math.max(1, v.eff)); v.hours = Math.min(24, v.hours); v.shiftH = Math.min(24, v.shiftH); v.life = Math.max(1, Math.min(60, v.life)); });
    let r; try { r = E.analyze(c); } catch (e) { thrown++; continue; }
    if (r.ok) { okCount++; if (/NaN|Infinity/.test(JSON.stringify(r))) bad1++; }
  }
  eq(GF, 'Geçerli 3000 girdide istisna yok', 0, thrown); eq(GF, 'Geçerli girdilerde NaN/Infinity yok', 0, bad1); truthy(GF, 'Girdilerin çoğu geçerli sayıldı', okCount > 2500, 'geçerli: ' + okCount);
  let thrown2 = 0; const junk = [undefined, null, NaN, Infinity, -Infinity, '', 'abc', [], {}, true, -1e308, 1e308];
  for (let i = 0; i < 2000; i++) { const c = base(); const kinds = ['robo', 'ice', 'ev']; const k = kinds[Math.floor(R() * 3)]; const fs = Object.keys(c.vehicles[k]); c.vehicles[k][fs[Math.floor(R() * fs.length)]] = junk[Math.floor(R() * junk.length)];
    try { const r = E.analyze(c); if (r.ok && /NaN|Infinity/.test(JSON.stringify(r))) thrown2++; } catch (e) { thrown2++; } }
  eq(GF, 'Bozuk değerli 2000 girdide istisna / NaN yok', 0, thrown2); }


/* ===== G. Operasyon göstergeleri (Aşama 3'te eklendi) ===== */
const GG = 'Operasyon göstergeleri';
{ const o = V.robo.ops, d = V.ice.ops;
  eqRel(GG, 'Filo günlük km = talep × sefer mesafesi', 8 * V.robo.tripKm, o.dailyKmFleet, 0.0001);
  eqRel(GG, 'Filo yıllık km = araç km × araç sayısı', V.robo.kmv * V.robo.n, o.annualKmFleet, 0.0001);
  eqRel(GG, 'Sefer başı kapasite = 1800 × %70', 1260, o.capacityKgPerTrip, 0.0001);
  eqRel(GG, 'Yıllık ton = sefer × kapasite', 8 * 300 * 1.26, o.annualTonnes, 0.0001);
  eqRel(GG, 'Robovan operatör FTE = vardiya × araç / oran', V.robo.shifts * V.robo.n / 5, o.staff, 0.0001);
  eqRel(GG, 'Dizel sürücü = vardiya × araç', V.ice.shifts * V.ice.n, d.staff, 0.0001);
  eq(GG, 'Dizel enerji birimi', 'L', d.energyUnit); eq(GG, 'Robovan enerji birimi', 'kWh', o.energyUnit);
  eqRel(GG, 'Dizel yakıt maliyeti = litre × fiyat', V.ice.energy * V.ice.n, d.energyQty * 1.5, 0.0001);
  eqRel(GG, 'Günlük filo maliyeti × gün = yıllık', V.robo.fleet, o.dailyCostFleet * 300, 0.0001);
  eqRel(GG, 'Aylık filo maliyeti × 12 = yıllık', V.robo.fleet, o.monthlyCostFleet * 12, 0.0001); }

/* ===== Rapor ===== */
const groups = [...new Set(rows.map((r) => r.group))];
let out = '';
groups.forEach((g) => {
  out += `\n## ${g}\n| Test | Beklenen | Gerçekleşen | Sonuç |\n|---|---|---|---|\n`;
  rows.filter((r) => r.group === g).forEach((r) => { out += `| ${r.name} | ${r.expected} | ${r.actual} | ${r.pass ? 'GEÇTİ' : '**KALDI**'} |\n`; });
});
console.log(out);
console.log(`\nToplam: ${rows.length}  Geçen: ${rows.length - fail}  Kalan: ${fail}`);
console.log('\nHam değerler:', JSON.stringify({ routeKm: r0.route.km, tripH: [V.robo.tripH, V.ice.tripH, V.ev.tripH], perKm: [V.robo.perKm, V.ice.perKm, V.ev.perKm], fleet: [V.robo.fleet, V.ice.fleet, V.ev.fleet], be: r0.kpi.breakEven }));
process.exit(fail ? 1 : 0);

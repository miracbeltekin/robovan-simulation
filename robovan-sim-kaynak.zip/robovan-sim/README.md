# Robovan Maliyet Simülatörü

Robovan (L4 otonom), dizel van ve elektrikli van için rota, maliyet, geri ödeme ve duyarlılık karşılaştırması.
**Nihai çıktı tek dosyadır: `dist/index.html`** (kopyası `index.html`, ≈1,6 MB). Sunucu, hesap, anahtar veya veritabanı yoktur.
Harita kütüphanesi (MapLibre GL JS 4.7.1, BSD-3) ve 3D araç için Three.js (r152, MIT) dosyanın içine gömülüdür.
Görünen ürün adı **Robovan**'dır.

## Kullanım
`index.html` dosyasını tarayıcıda açın (doğrudan dosya olarak veya localhost'tan). Hesaplama ve grafikler internetsiz çalışır.
Harita, rota ve adres arama için internet gerekir; anahtar gerekmez.

## Dış servisler (ücretsiz, anahtarsız, kredi kartsız)
| Servis | Ne için | Sınırlama |
|---|---|---|
| tiles.openfreemap.org | Harita karoları ve stil (OpenStreetMap verisi) | gönüllü/bağış destekli |
| router.project-osrm.org, yedek routing.openstreetmap.de | OSRM karayolu rotası, otomobil profili | adil kullanım; kamyonet kısıtları yok |
| photon.komoot.io | Adres arama (yalnız Ara/Enter) | adil kullanım |

İstekler: tek hat, en az 1,1 sn aralık, önceki istek iptal, rota önbelleği (14 gün, en çok 12 rota). Servisler çalışmazsa hesap tahminle sürer.

## Dosya yapısı
```
src/            hesap motoru (saf fonksiyonlar): defaults, geo, validate, engine, index
ui/             arayüz: index.template.html, styles.css, data.js, map.js (MapLibre + servisler), van3d.js (Three.js araç), charts.js, app.js
vendor/         maplibre-gl.js/css, three.min.js ve lisansları (build sırasında dosyaya gömülür)
tools/          build.js (motor paketi), build-ui.js (tek dosya index.html üretir)
tests/          run.js (105 motor testi), independent_check.py, ui-check*.js, render-real.js, fixtures/ (OSRM/Photon kayıtları)
docs/           şartname, analiz raporu, harita test rehberi
dist/           derleme çıktısı
```

## Komutlar (Node 18+, Python 3)
```
npm run build            # dist/index.html üretir
npm test                 # 105 motor testi
npm run test:independent # bağımsız Python hesabı (400 senaryo)
npm run test:ui          # arayüz testleri (Playwright; internet gerekir: gerçek OpenFreeMap karoları)
npm run test:render      # ekran görüntüleri (shots/)
```

## Hesap kararları (değişmez)
Rota 56,09 km (Gebze→İzmit, kuş uçuşu × 1,3), sürücü maliyeti 12 ay sabit, para birimi yalnız etiket, ülke ön ayarı yok.
Tüm tutarlar örnek varsayımdır; gerçek teklif değildir.

## Lisans notu
MapLibre GL JS (BSD-3-Clause) ve Three.js (MIT) lisans metinleri `vendor/` altındadır. Harita verisi © OpenStreetMap katkıcıları (ODbL), © OpenMapTiles.

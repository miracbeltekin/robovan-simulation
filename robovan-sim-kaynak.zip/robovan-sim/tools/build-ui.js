'use strict';
/* index.html üretir: motor + veri + harita + grafikler + uygulama + css tek dosyada. Harita kütüphanesi ve Three.js gömülüdür; açılışta yalnız harita/rota servislerine istek gider. */
const fs = require('fs'), path = require('path');
const r = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');
require('./build.js');
let html = r('ui/index.template.html');
const swap = (k, v) => { html = html.split(k).join('\n' + v.replace(/<\/script>/g, '<\\/script>') + '\n'); };
swap('/*__CSS__*/', r('ui/styles.css')); swap('/*__ENGINE__*/', r('dist/engine.bundle.js')); swap('/*__DATA__*/', r('ui/data.js'));
swap('/*__MAPLIBRE__*/', r('vendor/maplibre-gl.js')); swap('/*__MAPLIBRE_CSS__*/', r('vendor/maplibre-gl.css')); swap('/*__THREE__*/', r('vendor/three.min.js')); swap('/*__VAN3D__*/', r('ui/van3d.js')); swap('/*__MAP__*/', r('ui/map.js')); swap('/*__CHARTS__*/', r('ui/charts.js')); swap('/*__APP__*/', r('ui/app.js'));
const b64 = (p) => fs.readFileSync(path.join(__dirname, '..', p)).toString('base64');
html = html.split('/*__LOGO__*/').join('data:image/png;base64,' + b64('assets/tripy-robovan-logo.png')).split('/*__FAVICON__*/').join('data:image/png;base64,' + b64('assets/favicon.png'));
fs.writeFileSync(path.join(__dirname, '../dist/index.html'), html);
console.log('dist/index.html', html.length, 'bayt');

# Proje notları
- Görünen ürün adı **Robovan** (Robovan Maliyet Simülatörü). "Robotaxi" ismi hiçbir yerde kullanılmaz; yalnızca referans site adıdır.
- Hesap kararları: rota 56,09 km, sürücü maliyeti 12 ay sabit, para birimi yalnız etiket, ülke ön ayarı yok.
- Harita altyapısı: MapLibre GL JS + OpenFreeMap (anahtarsız). Mapbox tamamen kaldırıldı.
- Rota OSRM (yedek FOSSGIS OSRM, otomobil profili); adres arama Photon (yalnız Ara/Enter).

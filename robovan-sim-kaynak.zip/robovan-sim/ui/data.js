/* Arayüz verisi: şehir listesi, form şeması, metinler. Hesap formülü içermez. */
(function (root) {
'use strict';
const CITIES = [
['Gebze',40.8028,29.4307],['İzmit (Kocaeli)',40.7654,29.9408],['İstanbul',41.0082,28.9784],['Ankara',39.9334,32.8597],
['İzmir',38.4237,27.1428],['Bursa',40.1885,29.0610],['Antalya',36.8969,30.7133],['Adana',37.0,35.3213],['Konya',37.8746,32.4932],
['Gaziantep',37.0662,37.3833],['Eskişehir',39.7767,30.5206],['Kayseri',38.7312,35.4787],['Samsun',41.2867,36.33],['Trabzon',41.0027,39.7168],
['Mersin',36.8121,34.6415],['Diyarbakır',37.9144,40.2306],['Tekirdağ',40.9833,27.5167],['Sakarya',40.7569,30.3783],['Edirne',41.6771,26.5557],
['Denizli',37.7765,29.0864],['Muğla',37.2153,28.3636],['Berlin',52.52,13.405],['Münih',48.1351,11.582],['Frankfurt',50.1109,8.6821],['Dubai',25.2048,55.2708]
].map((c) => ({ n: c[0], lat: c[1], lon: c[2] }));

/* [anahtar, etiket, birim, adım, araçlar] — birimde "$" para birimi etiketiyle değişir */
const SCHEMA = [
{ g: 'Satın alma ve değer', f: [['price','Araç alış bedeli','$'],['infra','Şarj / altyapı (araç başına)','$'],['residual','Kalıntı değer','%'],['life','Ekonomik ömür','yıl'],['eng','Mühendislik + haritalama (filo toplamı, tek sefer)','$','robo']] },
{ g: 'Enerji', f: [['l100','Yakıt tüketimi','L/100 km','ice'],['fuel','Yakıt fiyatı','$/L','ice'],['kwh100','Elektrik tüketimi','kWh/100 km','ev,robo'],['elec','Elektrik fiyatı','$/kWh','ev,robo'],['eff','Şarj verimi','%','ev,robo'],['chargeKw','Şarj gücü','kW','ev,robo'],['range','Menzil','km','ev,robo']] },
{ g: 'Bakım ve sabit giderler', f: [['maint','Bakım','$/km'],['tire','Lastik','$/km'],['ins','Sigorta','$/yıl'],['tax','Vergi, muayene','$/yıl'],['lic','Yazılım + bağlantı lisansı','$/ay','robo']] },
{ g: 'Personel', f: [['driver','Sürücü maliyeti (işveren)','$/ay','ice,ev'],['operator','Uzaktan operatör maliyeti','$/ay','robo'],['ratio','Operatör başına araç','araç','robo'],['shiftH','Vardiya süresi','saat']] },
{ g: 'Kapasite ve hız', f: [['payload','Azami yük','kg'],['speed','Ortalama hız','km/sa'],['hours','Günlük çalışma süresi','saat/gün']] }
];

const SCENARIO_FIELDS = [
['days','Çalışma günü','gün/yıl'],['demand','Günlük toplam sefer (tüm iş)','sefer/gün'],['stops','Sefer başına durak','adet'],['loadMin','Durak başına yükleme','dk'],
['loadPct','Ortalama yük doluluğu','%'],['rate','Sermaye maliyeti','%/yıl'],['horizon','Değerlendirme süresi','yıl'],['fleet','Robovan sayısını sabitle (0 = otomatik)','adet']];

/* Ana kaydırıcılar. group: aynı değerin yazıldığı yollar. Doğrusal ölçek (onaylı karar). */
const SLIDERS = [
{ id: 'sl.demand', label: 'Günlük toplam sefer', unit: 'sefer/gün', min: 1, max: 40, step: 1, paths: ['s.demand'] },
{ id: 'sl.elec', label: 'Elektrik fiyatı', unit: '$/kWh', min: 0.01, max: 1.5, step: 0.01, paths: ['v.robo.elec', 'v.ev.elec'] },
{ id: 'sl.fuel', label: 'Dizel yakıt fiyatı', unit: '$/L', min: 0.1, max: 5, step: 0.05, paths: ['v.ice.fuel'] },
{ id: 'sl.driver', label: 'Sürücü aylık maliyeti', unit: '$/ay', min: 0, max: 10000, step: 50, paths: ['v.ice.driver', 'v.ev.driver'] },
{ id: 'sl.operator', label: 'Robovan operatör aylık maliyeti', unit: '$/ay', min: 0, max: 10000, step: 50, paths: ['v.robo.operator'] }
];

const PRESETS = [['Gebze → İzmit', ['Gebze', 'İzmit (Kocaeli)']], ['İstanbul → Bursa', ['İstanbul', 'Bursa']], ['İstanbul → Ankara', ['İstanbul', 'Ankara']], ['Ankara → Eskişehir', ['Ankara', 'Eskişehir']], ['Gebze → İzmit → Sakarya (3 durak)', ['Gebze', 'İzmit (Kocaeli)', 'Sakarya']]];
const TIPS = [['Rotayı seçin', 'Soldaki rota kartından şehir ekleyin, adres arayın ya da haritaya tıklayarak durak koyun. Mesafe maliyete doğrudan yansır.'], ['Parametreleri oynatın', 'Günlük sefer, elektrik, yakıt ve personel kaydırıcılarını değiştirin. Sonuçlar, grafikler ve sıralama anında güncellenir.'], ['Sonucu okuyun', 'Büyük rakam seçili tabana göre yıllık tasarruftur. Altta geri ödeme, başa baş sürücü maliyeti ve 5 yıllık fark vardır.']];
const NAMES = { robo: 'Robovan (L4 otonom)', ice: 'Dizel van (sürücülü)', ev: 'Elektrikli van (sürücülü)' };
const SHORT = { robo: 'Robovan', ice: 'Dizel van', ev: 'Elektrikli van' };

const FORMULAS = [
['Araç sayısı', 'Sefer süresi = yol süresi + (durak × yükleme süresi) + elektrikli araçlarda şarj süresi. Bir araç günde çalışma süresi ÷ sefer süresi (aşağı yuvarlanır, en az 1) sefer yapabilir. Gereken araç = günlük toplam sefer ÷ bu sayı (yukarı yuvarlanır). Robovan sayısı sabitlenirse o sayı kullanılır.'],
['Enerji', 'Yıllık km × tüketim × birim fiyat. Elektrikli araçlarda tüketim şarj verimine bölünür.'],
['Personel', 'Sürücülü araçta aylık sürücü maliyeti × 12 × vardiya sayısı. Robovanda aylık operatör maliyeti × 12 × vardiya sayısı ÷ operatör başına araç sayısı. Sürücü maliyeti 12 ay sabittir.'],
['Bakım, lastik, sabit', 'Yıllık km × (bakım + lastik) + sigorta + vergi (+ robovanda lisans × 12).'],
['Sermaye', 'Amortisman = (yatırım − kalıntı değer) ÷ ömür. Finansman = ortalama bağlı sermaye × yıllık oran. Robovan yatırımına mühendislik bedeli (filo toplamı ÷ araç sayısı) dahildir.'],
['Birim maliyet', 'km başına = yıllık toplam ÷ yıllık km. Sefer başına = yıllık toplam ÷ yıllık sefer. Ton-km başına = yıllık toplam ÷ (yıllık km × yük × doluluk).'],
['Tasarruf ve yüzde', 'Yıllık tasarruf = seçili tabanın yıllık filo maliyeti − robovanın yıllık filo maliyeti. 3 aylık = yıllık ÷ 4. Maliyet düşüşü = tasarruf ÷ tabanın filo maliyeti.'],
['Geri ödeme (başa baş)', 'İlk yatırım farkı ÷ yıllık nakit işletme farkı. Amortisman, finansman ve kalıntı değer dahil değildir.'],
['Başa baş sürücü maliyeti', 'Seçili tabandaki aracın aylık sürücü maliyeti hangi değerde yıllık filo maliyetini robovanla eşitler.'],
['5 yıllık toplam fark', 'Değerlendirme süresi boyunca yatırım + işletme, kalıntı değer düşülmüş toplam maliyet farkı.']
];

root.RobovanUIData = { PRESETS, TIPS, CITIES, SCHEMA, SCENARIO_FIELDS, SLIDERS, NAMES, SHORT, FORMULAS };
})(window);

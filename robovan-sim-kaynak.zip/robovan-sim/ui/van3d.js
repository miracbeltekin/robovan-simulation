/* Robovan 3D aracı: MapLibre özel katmanında Three.js ile çizilir. Model kod ile üretilir (dış model dosyası yok).
   Tam model (ayrıntılı) ve sade model (az parça, ışıksız malzeme) vardır; düşük performansta sade modele geçilir. */
(function (root) {
'use strict';
var TEAL = 0x1FC2AE, BRAND = 0xFF671D;

function buildVan(THREE, simple) {
  var g = new THREE.Group();
  function mat(color, opts) { return simple ? new THREE.MeshBasicMaterial(Object.assign({ color: color, side: THREE.DoubleSide }, opts || {})) : new THREE.MeshLambertMaterial(Object.assign({ color: color, side: THREE.DoubleSide }, opts || {})); }
  function basic(color, opts) { return new THREE.MeshBasicMaterial(Object.assign({ color: color, side: THREE.DoubleSide }, opts || {})); }
  function box(w, l, h, x, y, z, m) { var b = new THREE.Mesh(new THREE.BoxGeometry(w, l, h), m); b.position.set(x, y, z); g.add(b); return b; }
  /* model ekseni: X yan, Y ön, Z yukarı; ölçüler metre */
  box(2.2, 5.4, 2.0, 0, 0, 1.55, mat(0xF2F5F7));                      /* gövde */
  box(2.26, 5.0, 0.36, 0, -0.1, 0.92, mat(TEAL));                     /* turkuaz alt şerit */
  box(2.0, 0.14, 1.05, 0, 2.74, 1.5, mat(0x0E1A1F));                  /* ön sensör yüzü */
  box(1.55, 0.08, 0.1, 0, 2.82, 1.1, basic(0x7DFFEA));                /* ışıklı sensör şeridi */
  box(2.1, 5.2, 0.3, 0, 0, 0.62, mat(0x22262D));                      /* şasi */
  /* yer gölgesi */
  var sh = new THREE.Mesh(new THREE.PlaneGeometry(2.9, 6.4), basic(0x000000, { transparent: true, opacity: 0.38, depthWrite: false })); sh.position.set(0, 0, 0.03); g.add(sh);
  var wheel = function (x, y) {
    var w = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.52, 0.36, simple ? 8 : 18), basic(0x14161A)); w.rotation.z = Math.PI / 2; w.position.set(x, y, 0.52); g.add(w);
    if (!simple) { var h = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.38, 12), basic(0x8A93A3)); h.rotation.z = Math.PI / 2; h.position.set(x + (x > 0 ? 0.01 : -0.01), y, 0.52); g.add(h); }
  };
  wheel(1.06, 1.9); wheel(-1.06, 1.9); wheel(1.06, -1.9); wheel(-1.06, -1.9);
  if (!simple) {
    var l = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.32, 14), mat(0x15181D)); l.rotation.x = Math.PI / 2; l.position.set(0, 2.2, 2.7); g.add(l);   /* lidar */
    box(0.34, 0.34, 0.2, 0, -2.2, 2.65, basic(BRAND));                                                                                                           /* turuncu işaret ışığı */
    box(0.34, 0.06, 0.14, 0.7, 2.8, 0.9, basic(0xFFFFFF)); box(0.34, 0.06, 0.14, -0.7, 2.8, 0.9, basic(0xFFFFFF));                                              /* farlar */
    box(0.05, 0.05, 1.5, 0, -2.72, 1.55, mat(0xB9C0C9));                                                                                                         /* arka kapı çizgisi */
    box(2.24, 0.05, 0.12, 0, 1.2, 2.56, mat(0xD9DEE3)); box(2.24, 0.05, 0.12, 0, -1.2, 2.56, mat(0xD9DEE3));                                                    /* tavan kirişleri */
  }
  return g;
}

function create(opts) {
  var THREE = root.THREE, ML = root.maplibregl, simple = !!opts.simple;
  var st = { lng: 0, lat: 0, brg: 0, visible: false }, map, renderer, scene, camera, group, built = null;
  function rebuild() {
    if (!scene) return; if (group) scene.remove(group);
    group = buildVan(THREE, simple); scene.add(group); built = simple;
  }
  var layer = {
    id: 'rv-van', type: 'custom', renderingMode: '3d',
    onAdd: function (m, gl) {
      map = m; camera = new THREE.Camera(); scene = new THREE.Scene();
      var d1 = new THREE.DirectionalLight(0xffffff, 0.95); d1.position.set(0.6, -0.4, 1).normalize(); scene.add(d1);
      scene.add(new THREE.AmbientLight(0xffffff, 0.78));
      renderer = new THREE.WebGLRenderer({ canvas: m.getCanvas(), context: gl, antialias: false }); renderer.autoClear = false;
      rebuild();
    },
    render: function (gl, matrix) {
      if (!st.visible || !group) return;
      if (built !== simple) rebuild();
      var mc = ML.MercatorCoordinate.fromLngLat([st.lng, st.lat], 0);
      var zoom = map.getZoom(), vis = Math.max(3.4, Math.min(150, Math.pow(2, 17.4 - zoom)));  /* görünür kalsın: yakında 3,4×, uzakta büyür */
      var s = mc.meterInMercatorCoordinateUnits() * vis;
      var rotZ = new THREE.Matrix4().makeRotationZ(-st.brg * Math.PI / 180);
      var l = new THREE.Matrix4().makeTranslation(mc.x, mc.y, mc.z).scale(new THREE.Vector3(s, -s, s)).multiply(rotZ);
      camera.projectionMatrix = new THREE.Matrix4().fromArray(matrix).multiply(l);
      renderer.resetState(); renderer.render(scene, camera);
    },
    onRemove: function () { try { renderer.dispose(); } catch (e) {} }
  };
  return {
    layer: layer,
    set: function (lng, lat, brg) { st.lng = lng; st.lat = lat; st.brg = brg; st.visible = true; if (map) map.triggerRepaint(); },
    hide: function () { st.visible = false; if (map) map.triggerRepaint(); },
    setSimple: function (v) { simple = !!v; if (map) map.triggerRepaint(); },
    isSimple: function () { return simple; },
    state: function () { return { lng: st.lng, lat: st.lat, brg: st.brg, visible: st.visible, simple: simple }; }
  };
}

root.RobovanVan3D = { create: create };
})(window);

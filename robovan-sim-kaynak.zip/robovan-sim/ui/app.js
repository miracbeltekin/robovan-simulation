/* Uygulama: durum, formlar, KPI, harita ve grafik bağlantıları. Hesap yalnızca RobovanEngine ile yapılır. */
(function () {
'use strict';
var E = window.RobovanEngine, D = window.RobovanUIData, M = window.RobovanMap, C = window.RobovanCharts;
var KEY = 'robovan-sim-ui-v2';
var KINDS = ['robo', 'ice', 'ev'];
var $ = function (id) { return document.getElementById(id); };
var cfg, ui, raw, mapState = 'idle';
var routeInfo = { kind: 'none' }, routeSeq = 0, last = null, lastA = null, planSig = '';

/* ---------- durum ---------- */
function freshUi() { return { cur: '$', tip: 0, tipDone: false, param: 'demand', metric: 'perKm', routeOpen: null }; }
function reset() { cfg = E.defaultConfig(); ui = freshUi(); raw = {}; }
reset();
function getPath(p) { var a = p.split('.'); if (a[0] === 's') return cfg.scenario[a[1]]; if (a[0] === 'v') return cfg.vehicles[a[1]][a[2]]; if (a[0] === 'r') return cfg.route[a[1]]; }
function setPath(p, v) { var a = p.split('.'); if (a[0] === 's') cfg.scenario[a[1]] = v; else if (a[0] === 'v') cfg.vehicles[a[1]][a[2]] = v; else if (a[0] === 'r') cfg.route[a[1]] = v; }
function slider(id) { return D.SLIDERS.filter(function (s) { return s.id === id; })[0]; }
function readId(id) { var s = slider(id); return s ? getPath(s.paths[0]) : getPath(id); }

/* ---------- biçim ---------- */
function parse(s) { s = String(s).trim().replace(/\s/g, ''); if (s === '') return NaN; if (s.indexOf(',') > -1) s = s.replace(/\./g, '').replace(',', '.'); return /^[-+]?(\d+\.?\d*|\.\d+)$/.test(s) ? Number(s) : NaN; }
function fmtIn(v) { return Number.isFinite(v) ? String(+v.toFixed(6)).replace('.', ',') : ''; }
function nf(x, d) { return Number.isFinite(x) ? x.toLocaleString('tr-TR', { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }) : '—'; }
function money(x, d) { if (x === null || !Number.isFinite(x)) return '—'; var neg = x < 0 && Math.round(Math.abs(x) * Math.pow(10, d || 0)) > 0; return (neg ? '−' : '') + ui.cur + nf(Math.abs(x), d || 0); }
function pct(x) { return Number.isFinite(x) ? (x < 0 ? '−' : '') + '%' + nf(Math.abs(x), 0) : '—'; }
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function unit(u) { return u.replace(/\$/g, ui.cur); }
function hm(min) { if (!Number.isFinite(min)) return '0:00'; var m = Math.round(min); return Math.floor(m / 60) + ':' + ('0' + (m % 60)).slice(-2); }

/* ---------- form kurulumu ---------- */
function fld(id, label, u) { return '<div class="fld"><label for="' + id + '">' + esc(label) + '</label><div class="inp"><input id="' + id + '" data-f="' + id + '" inputmode="decimal" autocomplete="off"><span class="u" data-u="' + esc(u) + '">' + esc(unit(u)) + '</span></div></div>'; }
function build() {
  $('sliders').innerHTML = D.SLIDERS.map(function (s) {
    return '<div class="slider"><div class="row"><label for="' + s.id + '">' + esc(s.label) + '</label><div class="val"><input id="' + s.id + '" data-f="' + s.id + '" inputmode="decimal" autocomplete="off"><span data-u="' + esc(s.unit) + '">' + esc(unit(s.unit)) + '</span></div></div><input type="range" data-r="' + s.id + '" min="' + s.min + '" max="' + s.max + '" step="' + s.step + '" aria-label="' + esc(s.label) + ' kaydırıcı"><div class="shared" data-shared="' + s.id + '" hidden>Araç kartlarında farklı değerler var</div></div>';
  }).join('');
  $('scFields').innerHTML = D.SCENARIO_FIELDS.map(function (f) { return fld('s.' + f[0], f[1], f[2]); }).join('');
  var h = '';
  KINDS.forEach(function (k) {
    h += '<div class="vcard ' + k + '"><h4>' + D.NAMES[k] + '</h4><div class="vsum" id="vsum-' + k + '"></div>';
    D.SCHEMA.forEach(function (g, gi) { var fs = g.f.filter(function (f) { return !f[3] || f[3].split(',').indexOf(k) > -1; }); h += '<details' + (gi === 0 || gi === 3 ? ' open' : '') + '><summary>' + g.g + '</summary><div class="fields">' + fs.map(function (f) { return fld('v.' + k + '.' + f[0], f[1], f[2]); }).join('') + '</div></details>'; });
    h += '</div>';
  });
  $('vgrid').innerHTML = h;
  $('cityPick').innerHTML = D.CITIES.map(function (c) { return '<option>' + esc(c.n) + '</option>'; }).join('');
  $('presets').innerHTML = D.PRESETS.map(function (p, i) { return '<button data-preset="' + i + '">' + esc(p[0]) + '</button>'; }).join('');
  $('howList').innerHTML = D.FORMULAS.map(function (f) { return '<details><summary>' + esc(f[0]) + '</summary><p>' + esc(f[1]) + '</p></details>'; }).join('');
  $('sensParam').innerHTML = C.PARAMS.map(function (p) { return '<option value="' + p.id + '">' + esc(p.label) + '</option>'; }).join('');
  $('sensMetric').innerHTML = C.METRICS.map(function (m) { return '<option value="' + m.id + '">' + esc(m.label) + '</option>'; }).join('');
}
function showValue(id) { var v = readId(id), r = raw[id]; return (r !== undefined && ((Number.isNaN(v) && Number.isNaN(parse(r))) || parse(r) === v)) ? r : fmtIn(v); }
function setSeg(id, on) { $(id).setAttribute('aria-pressed', on ? 'true' : 'false'); }
function syncInputs() {
  document.querySelectorAll('[data-f]').forEach(function (el) { var id = el.dataset.f, v = readId(id); if (document.activeElement !== el) el.value = showValue(id); el.setAttribute('aria-invalid', Number.isFinite(v) ? 'false' : 'true'); });
  D.SLIDERS.forEach(function (s) { var r = document.querySelector('[data-r="' + s.id + '"]'), v = getPath(s.paths[0]); r.value = Number.isFinite(v) ? Math.min(s.max, Math.max(s.min, v)) : s.min; var vals = s.paths.map(getPath); document.querySelector('[data-shared="' + s.id + '"]').hidden = !vals.some(function (x) { return x !== vals[0]; }); });
  $('cur').value = ui.cur; $('roundTrip').value = cfg.scenario.roundTrip ? '1' : '0';
  setSeg('baseIce', cfg.base === 'ice'); setSeg('baseEv', cfg.base === 'ev');
  setSeg('modeRoute', cfg.route.mode === 'route'); setSeg('modeManual', cfg.route.mode === 'manual');
  $('routeBody').hidden = cfg.route.mode !== 'route'; $('manualBox').hidden = cfg.route.mode !== 'manual'; $('rfBox').hidden = cfg.route.mode !== 'route';
  $('sensParam').value = ui.param; $('sensMetric').value = ui.metric;
  document.querySelectorAll('[data-u]').forEach(function (e) { e.textContent = unit(e.getAttribute('data-u')); });
  applyRouteOpen();
}

function routeOpen() { if (typeof ui.routeOpen === 'boolean') return ui.routeOpen; return mq.matches ? false : mapState !== 'ready'; }
function applyRouteOpen() { var o = routeOpen(), rc = $('routecard'); rc.classList.toggle('collapsed', !o); $('rcToggle').setAttribute('aria-expanded', o ? 'true' : 'false'); $('rcToggleTxt').textContent = o ? 'Daralt' : 'Genişlet'; }
$('rcToggle').onclick = function () { ui.routeOpen = !routeOpen(); applyRouteOpen(); save(); };

/* ---------- olaylar ---------- */
function onField(id, text) {
  raw[id] = text; var v = parse(text), s = slider(id);
  if (s) s.paths.forEach(function (p) { setPath(p, v); raw[p] = text; }); else setPath(id, v);
  if (id === 'r.manualKm' || id === 's.roadFactor') { /* mesafe kaynağı değişti */ }
  update();
}
document.addEventListener('input', function (e) {
  var t = e.target; if (!t.dataset) return;
  if (t.dataset.f) onField(t.dataset.f, t.value);
  else if (t.dataset.r) onField(t.dataset.r, String(+Number(t.value).toFixed(6)).replace('.', ','));
});
$('cur').addEventListener('change', function (e) { ui.cur = e.target.value; update(); });
$('baseIce').onclick = function () { cfg.base = 'ice'; update(); }; $('baseEv').onclick = function () { cfg.base = 'ev'; update(); };
$('modeRoute').onclick = function () { cfg.route.mode = 'route'; routeChanged(); }; $('modeManual').onclick = function () { cfg.route.mode = 'manual'; update(); };
$('roundTrip').addEventListener('change', function (e) { cfg.scenario.roundTrip = e.target.value === '1'; update(); });
$('reset').onclick = function () { reset(); renderWps(); routeChanged(); };
$('copy').onclick = copySummary;
$('sensParam').addEventListener('change', function (e) { ui.param = e.target.value; update(); }); $('sensMetric').addEventListener('change', function (e) { ui.metric = e.target.value; update(); });
['myNums', 'myNums2', 'myNums3'].forEach(function (id) { $(id).onclick = openSheet; });
function openSheet() { $('sheet').hidden = false; $('scrim').hidden = false; $('sheetClose').focus(); }
function closeSheet() { $('sheet').hidden = true; $('scrim').hidden = true; }
$('sheetClose').onclick = closeSheet; $('sheetDone').onclick = closeSheet; $('scrim').onclick = closeSheet;
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('sheet').hidden) closeSheet(); });
$('depsLink').onclick = function () { setTimeout(function () { $('deps').scrollIntoView({ behavior: 'smooth' }); }, 0); };

/* ilk kullanım ipucu */
function renderTip() {
  var c = $('tipcard'); if (ui.tipDone) { c.hidden = true; return; } c.hidden = false;
  var t = D.TIPS[ui.tip]; $('tcStep').textContent = 'Adım ' + (ui.tip + 1) + ' / ' + D.TIPS.length; $('tcTitle').textContent = t[0]; $('tcText').textContent = t[1];
  $('tcDots').innerHTML = D.TIPS.map(function (_, i) { return '<i class="' + (i === ui.tip ? 'on' : '') + '"></i>'; }).join(''); $('tcNext').textContent = ui.tip === D.TIPS.length - 1 ? 'Bitir' : 'İleri';
}
$('tcNext').onclick = function () { if (ui.tip >= D.TIPS.length - 1) ui.tipDone = true; else ui.tip++; renderTip(); save(); };
$('tcSkip').onclick = function () { ui.tipDone = true; renderTip(); save(); };

/* ---------- rota ve duraklar ---------- */
function city(n) { return D.CITIES.filter(function (c) { return c.n === n; })[0]; }
function cityWps(names) { return names.map(function (n) { var c = city(n); return { n: c.n, lat: c.lat, lon: c.lon }; }); }
function renderWps() {
  var w = cfg.route.waypoints;
  $('wps').innerHTML = w.map(function (x, i) { return '<div class="wp"><b>' + String.fromCharCode(65 + i % 26) + '</b><span title="' + esc(x.n) + '">' + esc(x.n) + '</span>' + (i > 0 ? '<button data-up="' + i + '" aria-label="Yukarı al">↑</button>' : '') + '<button data-del="' + i + '" aria-label="Durağı sil">×</button></div>'; }).join('') || '<p class="small muted">Durak yok. Şehir ekleyin, adres arayın ya da haritaya tıklayın.</p>';
  $('routeChip').textContent = w.length >= 2 ? w[0].n + ' → ' + w[w.length - 1].n + (w.length > 2 ? ' (+' + (w.length - 2) + ' durak)' : '') : 'Rota seçilmedi';
}
$('wps').addEventListener('click', function (e) {
  var d = e.target.closest('[data-del]'), u = e.target.closest('[data-up]'), w = cfg.route.waypoints;
  if (d) { w.splice(+d.getAttribute('data-del'), 1); routeChanged(); }
  else if (u) { var i = +u.getAttribute('data-up'); if (i > 0) { var x = w[i]; w[i] = w[i - 1]; w[i - 1] = x; routeChanged(); } }
});
$('cityAdd').onclick = function () { var c = city($('cityPick').value); addWp({ n: c.n, lat: c.lat, lon: c.lon }); };
$('presets').addEventListener('click', function (e) { var b = e.target.closest('[data-preset]'); if (!b) return; cfg.route.waypoints = cityWps(D.PRESETS[+b.getAttribute('data-preset')][1]); routeChanged(); });
function addWp(w) { if (cfg.route.waypoints.length >= 25) { toast('En fazla 25 durak eklenebilir.'); return; } cfg.route.waypoints.push(w); routeChanged(); }
$('addrGo').onclick = function () {
  var q = $('addr').value.trim(), box = $('sugg'); if (!q) return;
  if (q.length < 3) { box.innerHTML = '<p class="small muted">En az 3 harf yazın.</p>'; return; }
  box.innerHTML = '<p class="small muted">Aranıyor…</p>';
  var wp = cfg.route.waypoints, near = M.center() || (wp.length ? [wp[0].lon, wp[0].lat] : null);
  M.geocode(q, near).then(function (r) {
    if (!r.length) { box.innerHTML = '<p class="small muted">Sonuç bulunamadı. Daha açık bir adres yazın.</p>'; return; }
    box.innerHTML = r.map(function (x, i) { return '<button class="opt" data-s="' + i + '">' + esc(x.n) + '</button>'; }).join('');
    box.onclick = function (e) { var b = e.target.closest('[data-s]'); if (!b) return; addWp(r[+b.getAttribute('data-s')]); box.innerHTML = ''; $('addr').value = ''; };
  }).catch(function (err) { if (err.name === 'AbortError') return; box.innerHTML = '<p class="small" style="color:var(--bad)">' + esc(err.message) + '</p>'; });
};
$('addr').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('addrGo').click(); });
var tipTimer; function toast(msg) { var t = $('maptip'); t.textContent = msg; t.hidden = false; clearTimeout(tipTimer); tipTimer = setTimeout(function () { t.hidden = true; }, 3600); }

/* Rota değişti: karayolu rotasını OSRM'den iste (kısa gecikmeyle, önceki istek iptal). Hesaplanamazsa "tahmin" olarak işaretle, gerçek gibi gösterme. */
var routeTimer;
function routeChanged() {
  renderWps(); M.setWaypoints(cfg.route.waypoints);
  routeInfo = { kind: 'none' }; planSig = ''; M.setRoute(null); M.setPlan(null);
  clearTimeout(routeTimer); var seq = ++routeSeq, w = cfg.route.waypoints;
  if (cfg.route.mode === 'route' && w.length >= 2) { routeInfo = { kind: 'loading' }; routeTimer = setTimeout(function () { fetchRoute(seq); }, 350); }
  update();
}
function fetchRoute(seq) {
  M.route(cfg.route.waypoints.slice()).then(function (r) {
    if (seq !== routeSeq) return;
    routeInfo = { kind: 'road', km: r.km, min: r.minutes, coords: r.coords, legKm: r.legKm, provider: r.provider, cached: !!r.cached };
    M.setRoute({ kind: 'road', coords: r.coords }); M.fit(); update();
  }).catch(function (err) { if (err.name === 'AbortError' || seq !== routeSeq) return; routeInfo = { kind: 'air', error: err.message }; update(); });
}
$('addBtn').onclick = function () { var on = $('addBtn').getAttribute('aria-pressed') !== 'true'; $('addBtn').setAttribute('aria-pressed', on ? 'true' : 'false'); M.setAddMode(on); toast(on ? 'Haritaya tıklayarak durak ekleyin.' : 'Durak ekleme kapatıldı.'); };
$('followBtn').onclick = function () { var on = $('followBtn').getAttribute('aria-pressed') !== 'true'; $('followBtn').setAttribute('aria-pressed', on ? 'true' : 'false'); M.setFollow(on); };
document.querySelectorAll('[data-view]').forEach(function (b) { b.onclick = function () { M.view(b.getAttribute('data-view')); }; });

/* ---------- harita durumu ---------- */
function startMap() {
  M.init({ container: 'map', cb: {
    onState: onMapState, onNotice: toast,
    onMapClick: function (p) { addWp({ n: 'Nokta (' + p.lat.toFixed(3) + ', ' + p.lon.toFixed(3) + ')', lat: p.lat, lon: p.lon }); },
    onStopDrag: function (i, p) { var w = cfg.route.waypoints[i]; w.lat = p.lat; w.lon = p.lon; w.n = 'Nokta (' + p.lat.toFixed(3) + ', ' + p.lon.toFixed(3) + ')'; routeChanged(); },
    onFollow: function (on) { $('followBtn').setAttribute('aria-pressed', on ? 'true' : 'false'); },
    onTick: onTick } });
}
function onMapState(s, msg) {
  mapState = s; var box = $('mapstate'), t = $('msTitle'), x = $('msText');
  box.hidden = s === 'ready'; $('mapRetry').hidden = s !== 'error';
  if (s === 'loading') { t.textContent = 'Harita yükleniyor'; x.textContent = 'OpenStreetMap haritası (OpenFreeMap) indiriliyor…'; }
  else if (s === 'error') { t.textContent = 'Harita açılamadı'; x.textContent = msg + ' Hesaplama, grafikler ve elle mesafe/şehir listesi çalışmaya devam eder.'; }
  if (s === 'ready') { M.setWaypoints(cfg.route.waypoints); if (routeInfo.kind === 'road') { M.setRoute({ kind: 'road', coords: routeInfo.coords }); } M.fit(); syncPlan(); }
  ['addBtn', 'followBtn'].forEach(function (id) { $(id).disabled = s !== 'ready'; }); document.querySelectorAll('[data-view]').forEach(function (b) { b.disabled = s !== 'ready'; });
  update();
}
$('mapRetry').onclick = function () { startMap(); };

/* ---------- animasyon ---------- */
function syncPlan() {
  var r = routeInfo, v = cfg.vehicles.robo, ok = mapState === 'ready' && r.kind === 'road' && Number.isFinite(v.speed) && v.speed > 0 && Number.isFinite(cfg.scenario.loadMin);
  var sig = ok ? [v.speed, cfg.scenario.loadMin, cfg.scenario.roundTrip, r.coords.length, r.km.toFixed(2)].join('|') : '';
  if (sig === planSig) return; planSig = sig;
  M.setPlan(ok ? { coords: r.coords, legKm: r.legKm, speedKmh: v.speed, dwellMin: cfg.scenario.loadMin, roundTrip: cfg.scenario.roundTrip } : null);
}
function onTick(s) {
  $('timeline').classList.toggle('idle', !s.has);
  $('pp').textContent = s.playing ? '⏸' : '▶'; $('pp').disabled = !s.has; $('tl').disabled = !s.has; document.querySelectorAll('.sp').forEach(function (b) { b.disabled = !s.has; });
  $('clock').textContent = hm(s.t); if (s.has) { $('tl').value = s.duration > 0 ? Math.round(s.t / s.duration * 1000) : 0; $('tlTxt').textContent = 'Simüle sefer süresi ' + hm(s.t) + ' / ' + hm(s.duration) + ' (gösterim: hız ve yükleme süresi parametrelerinden)'; }
  else $('tlTxt').textContent = mapState === 'ready' ? 'Animasyon için gerçek karayolu rotası gerekir (en az 2 durak, Rotadan modu, rota servisine erişim).' : 'Animasyon için harita ve gerçek karayolu rotası gerekir.';
}
$('pp').onclick = function () { if (M.isPlaying()) M.pause(); else M.play(); };
document.querySelectorAll('.sp').forEach(function (b) { b.onclick = function () { M.setSpeed(+b.getAttribute('data-sp')); document.querySelectorAll('.sp').forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); }); }; });
$('tl').addEventListener('input', function (e) { var tl = M.timeline(); if (tl) { M.pause(); M.seek(+e.target.value / 1000 * tl.duration); } });

/* ---------- çizim ---------- */
var raf = 0; function update() { syncInputs(); syncPlan(); if (!raf) raf = requestAnimationFrame(function () { raf = 0; draw(); }); save(); }
function analyzeOpts() { return routeInfo.kind === 'road' ? { roadKm: routeInfo.km } : {}; }
function draw() {
  var a = E.analyze(cfg, analyzeOpts()), warns = [];
  var sp = cfg.vehicles.robo;
  if (!a.ok) { a.errors.forEach(function (m) { warns.push(['err', m]); }); if (last) warns.push(['', 'Sonuçlar son geçerli girdilere aittir. Hataları düzeltin.']); $('resultCard').style.opacity = .5; }
  else { $('resultCard').style.opacity = 1; last = a; a.warnings.forEach(function (m) { warns.push(['', m]); }); }
  if (cfg.route.mode === 'route' && routeInfo.kind === 'air' && routeInfo.error) warns.push(['', 'Karayolu rotası hesaplanamadı: ' + routeInfo.error + ' Mesafe kuş uçuşu × yol katsayısıyla tahmin ediliyor.']);
  $('warns').innerHTML = warns.map(function (w) { return '<div class="warn ' + w[0] + '">' + esc(w[1]) + '</div>'; }).join('');
  var r = a.ok ? a : last; if (!r) return; lastA = r;
  var V = r.vehicles, K = r.kpi, B = V[K.base], R = V.robo, sc = r.config.scenario, rt = r.route;
  renderRoute(r);
  /* sonuç kartı */
  var sav = K.annualSaving, red = B.fleet > 0 ? sav / B.fleet * 100 : NaN, trips = sc.demand * sc.days;
  $('rLbl').textContent = (sav >= 0 ? 'Tahmini yıllık tasarruf' : 'Tahmini yıllık ek maliyet') + ' · robovan, ' + D.SHORT[K.base].toLowerCase() + ' yerine';
  var big = $('rBig'); big.textContent = (sav < 0 ? '−' : '') + money(Math.abs(sav)).replace('−', ''); big.className = 'big' + (sav < 0 ? ' bad' : '');
  $('rSub').textContent = pct(red) + (sav >= 0 ? ' maliyet düşüşü' : ' maliyet artışı') + ' · ' + sc.demand + ' sefer/gün · ' + R.n + ' robovan, ' + B.n + ' ' + D.SHORT[K.base].toLowerCase();
  setK('k-trip', trips > 0 ? sav / trips : NaN); setK('k-q', sav / 4); setK('k-year', sav);
  var mx = Math.max(R.fleet, V.ice.fleet, V.ev.fleet, 1);
  $('miniBars').innerHTML = KINDS.map(function (k) { return '<div class="mb"><span>' + D.SHORT[k] + '</span><i class="' + k + '" style="width:' + Math.max(4, V[k].fleet / mx * 100 * 0.52).toFixed(1) + '%"></i><b>' + money(V[k].fleet) + '</b></div>'; }).join('');
  $('rFoot').textContent = 'Yıllık filo maliyeti · ' + nf(rt.km, 1) + ' km tek yön (' + sourceName(rt.source) + ')';
  /* sıralama */
  var order = KINDS.slice().sort(function (x, y) { var a1 = V[x].perKm, b1 = V[y].perKm; return (a1 === null ? Infinity : a1) - (b1 === null ? Infinity : b1); });
  $('rank').innerHTML = order.map(function (k, i) { var c = V[k]; return '<div class="rk"><div class="n ' + k + '">' + (i + 1) + '</div><div class="t"><b>' + D.SHORT[k] + '</b><span>' + c.n + ' araç · sefer ' + nf(c.tripH, 1) + ' sa · ' + c.shifts + ' vardiya</span></div><div class="v"><b>' + (c.perKm === null ? '—' : money(c.perKm, 2)) + '</b><span>günlük ' + money(c.ops.dailyCostFleet) + '</span></div></div>'; }).join('');
  /* geri ödeme / toplam */
  var be = K.breakEven, bw = K.breakEvenWage;
  $('extra').innerHTML = [
    stat('Geri ödeme (başa baş)', esc(be.label), 'ilk yatırım farkı ' + money(K.investmentDiff), be.status === 'never' ? 'bad' : (be.years !== null && be.years <= sc.horizon ? 'good' : 'warn')),
    stat('Başa baş sürücü maliyeti', esc(bw.label || money(bw.value) + '/ay'), 'şu an ' + money(cfg.vehicles[K.base].driver) + '/ay', ''),
    stat(nf(sc.horizon, 0) + ' yıllık toplam fark', (K.tcoSaving >= 0 ? '+' : '−') + money(Math.abs(K.tcoSaving)).replace('−', ''), K.tcoSaving >= 0 ? 'robovan lehine, kalıntı değer düşülmüş' : 'robovan aleyhine', K.tcoSaving >= 0 ? 'good' : 'bad'),
    stat('Robovan işletme', money(R.ops.dailyCostFleet) + '/gün', money(R.ops.monthlyCostFleet) + '/ay · yıllık ' + money(R.fleet), '')
  ].join('');
  KINDS.forEach(function (k) { $('vsum-' + k).textContent = V[k].n + ' araç · ' + (V[k].perKm === null ? '—' : nf(V[k].perKm, 2)) + ' ' + ui.cur + '/km · yıllık ' + money(V[k].fleet); });
  /* grafikler */
  $('lgBars').innerHTML = C.bars($('chBars'), r, ui.cur);
  var marks = C.cumulative($('chCum'), r, ui.cur, E);
  $('cumNote').textContent = marks.length ? marks.join(' · ') + '. Kesikli çizgi değerlendirme süresidir.' : 'Başa baş noktası 10 yıl içinde yok. Kesikli çizgi değerlendirme süresidir.';
  var lg = KINDS.map(function (k) { return '<span><i style="background:var(--' + k + ')"></i>' + D.NAMES[k] + '</span>'; }).join('');
  $('lgVeh').innerHTML = lg; $('lgVeh2').innerHTML = lg;
  $('sensNote').textContent = C.sensitivity($('chSens'), r, ui.cur, { param: ui.param, metric: ui.metric }, function (c) { return E.analyze(c, analyzeOpts()); }) || 'Dikey çizgi şu anki değerdir.';
  tables(r);
  window.__last = r;
}
function setK(id, v) { var el = $(id); el.textContent = money(v); el.className = Number.isFinite(v) && v < 0 ? 'bad' : ''; }
function stat(l, v, d, cls) { return '<div class="stat"><div class="l">' + l + '</div><div class="v ' + cls + '">' + v + '</div><div class="d">' + d + '</div></div>'; }
function sourceName(s) { return { road: 'OSRM karayolu', air: 'kuş uçuşu tahmini', manual: 'elle girilen' }[s] || s; }
function renderRoute(r) {
  var rt = r.route, sc = r.config.scenario, h;
  var badge = rt.source === 'road' ? '<span class="badge road">Gerçek karayolu mesafesi (' + esc(routeInfo.provider || 'OSRM') + ', otomobil)' + (routeInfo.cached ? ' · önbellekten' : '') + '</span>' : rt.source === 'manual' ? '<span class="badge man">Elle girilen mesafe</span>' : '<span class="badge est">Tahmin: kuş uçuşu × ' + nf(sc.roadFactor, 2) + ' (gerçek yol değil)</span>';
  h = '<div class="km">' + nf(rt.km, 1) + ' <small>km tek yön' + (sc.roundTrip ? ' · sefer ' + nf(rt.km * 2, 1) + ' km' : '') + '</small></div>' + badge;
  if (routeInfo.kind === 'loading') h += '<p>Karayolu rotası hesaplanıyor…</p>';
  if (rt.source === 'road') h += '<p>Rota otomobil profiliyle hesaplanır; <b>kamyonet kısıtları (yükseklik, ağırlık, geçiş ücreti) dikkate alınmaz.</b>' + (routeInfo.min ? ' Yol süresi yaklaşık ' + hm(routeInfo.min) + ' (trafiksiz); maliyet hesabı kendi ortalama hız varsayımınızı kullanır.' : '') + '</p>';
  if (cfg.route.mode === 'route' && routeInfo.kind === 'air' && routeInfo.error) h += '<p class="err">' + esc(routeInfo.error) + '</p>';
  if (cfg.route.mode === 'route' && routeInfo.kind === 'none' && rt.source === 'air') h += '<p>Gerçek yol mesafesi için en az iki durak gerekir; şimdilik tahmin kullanılıyor.</p>';
  $('rcRes').innerHTML = h;
  var wps = cfg.route.waypoints, nm = wps.length >= 2 ? esc(wps[0].n) + ' → ' + esc(wps[wps.length - 1].n) : 'Rota seçilmedi';
  $('rcSum').innerHTML = '<b>' + nm + '</b><br>' + nf(rt.km, 1) + ' km tek yön · ' + (rt.source === 'road' ? 'OSRM karayolu' : rt.source === 'manual' ? 'elle girilen' : 'tahmin (gerçek yol değil)') + (wps.length > 2 ? ' · ' + wps.length + ' durak' : '');
}
function tables(r) {
  var V = r.vehicles, sc = r.config.scenario;
  var ops = [
    ['sec', 'Filo ve sefer'], ['Araç sayısı', function (c) { return nf(c.n); }], ['Araç başına sefer / gün', function (c) { return nf(c.tpv, 2); }], ['Sefer süresi (saat)', function (c) { return nf(c.tripH, 2); }], ['Günlük kullanılan süre (araç başına, saat)', function (c) { return nf(c.usedH, 1); }],
    ['sec', 'Kilometre ve kapasite'], ['Günlük km (filo)', function (c) { return nf(c.ops.dailyKmFleet); }], ['Yıllık km (filo)', function (c) { return nf(c.ops.annualKmFleet); }], ['Sefer başına taşıma kapasitesi (kg)', function (c) { return nf(c.ops.capacityKgPerTrip); }], ['Yıllık taşınan yük (ton)', function (c) { return nf(c.ops.annualTonnes, 1); }],
    ['sec', 'Personel ve enerji'], ['Vardiya sayısı', function (c) { return nf(c.shifts); }], ['Personel (tam zamanlı eşdeğer)', function (c) { return nf(c.ops.staff, 1) + (c.ops.staffKind === 'operator' ? ' operatör' : ' sürücü'); }], ['Yıllık enerji / yakıt', function (c) { return nf(c.ops.energyQty) + ' ' + c.ops.energyUnit; }]
  ];
  $('opsTable').innerHTML = tableHtml(ops, V);
  var rows = [
    ['sec', 'Yıllık maliyet (araç başına)'], ['Enerji', function (c) { return money(c.energy); }], ['Bakım + lastik', function (c) { return money(c.maint); }], ['Personel', function (c) { return money(c.people); }], ['Sigorta, vergi, lisans', function (c) { return money(c.fixed); }], ['Amortisman', function (c) { return money(c.dep); }], ['Finansman', function (c) { return money(c.fin); }], ['Toplam', function (c) { return money(c.total); }, 1],
    ['sec', 'Birim maliyet'], ['km başına', function (c) { return money(c.perKm, 2); }], ['Sefer başına', function (c) { return money(c.perTrip, 2); }], ['Ton-km başına', function (c) { return money(c.perTonKm, 3); }],
    ['sec', 'Filo toplamı'], ['Günlük işletme maliyeti', function (c) { return money(c.ops.dailyCostFleet); }], ['Aylık işletme maliyeti', function (c) { return money(c.ops.monthlyCostFleet); }], ['Yıllık filo maliyeti', function (c) { return money(c.fleet); }, 1], ['İlk yatırım', function (c) { return money(c.capexFleet); }], [nf(sc.horizon, 0) + ' yıllık toplam sahip olma maliyeti', function (c) { return money(c.tco(sc.horizon)); }]
  ];
  $('table').innerHTML = tableHtml(rows, V);
}
function tableHtml(rows, V) {
  var t = '<thead><tr><th></th>' + KINDS.map(function (k) { return '<th><span class="dot ' + k + '"></span>' + D.SHORT[k] + '</th>'; }).join('') + '</tr></thead><tbody>';
  rows.forEach(function (x) { if (x[0] === 'sec') t += '<tr class="sec"><td colspan="4">' + x[1] + '</td></tr>'; else t += '<tr><td>' + esc(x[0]) + '</td>' + KINDS.map(function (k) { return '<td' + (x[2] ? ' class="strong"' : '') + '>' + x[1](V[k]) + '</td>'; }).join('') + '</tr>'; });
  return t + '</tbody>';
}
function copySummary() {
  var r = window.__last; if (!r) return; var V = r.vehicles, B = V[r.kpi.base], R = V.robo;
  var txt = 'Robovan maliyet simülasyonu (örnek varsayımlarla)\nRota: ' + nf(r.route.km, 1) + ' km tek yön (' + sourceName(r.route.source) + '), günlük ' + nf(r.config.scenario.demand) + ' sefer\n' +
    'Robovan: ' + R.n + ' araç, ' + nf(R.perKm, 2) + ' ' + ui.cur + '/km, yıllık ' + money(R.fleet) + '\n' + D.SHORT[r.kpi.base] + ': ' + B.n + ' araç, ' + nf(B.perKm, 2) + ' ' + ui.cur + '/km, yıllık ' + money(B.fleet) + '\nYıllık fark: ' + money(r.kpi.annualSaving) + '\nGeri ödeme: ' + r.kpi.breakEven.label;
  var b = $('copy'); function ok() { b.textContent = 'Kopyalandı'; setTimeout(function () { b.textContent = 'Özeti Kopyala'; }, 1600); }
  function fb() { var ta = document.createElement('textarea'); ta.value = txt; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); ok(); } catch (e) {} document.body.removeChild(ta); }
  try { navigator.clipboard.writeText(txt).then(ok, fb); } catch (e) { fb(); }
}

/* mobilde rota kartı panele, animasyon kontrolleri haritanın üstüne taşınır */
var mq = window.matchMedia('(max-width: 900px)');
function placeRoute() {
  var rc = $('routecard'), pill = $('pill'), clock = $('clock');
  if (mq.matches) { $('panel').insertBefore(rc, $('ctrlCard')); $('mapctl').appendChild(pill); $('mapctl').appendChild(clock); }
  else { $('mapcard').insertBefore(rc, $('timeline')); $('mid').appendChild(clock); $('mid').appendChild(pill); }
  applyRouteOpen(); M.resize();
}
mq.addEventListener ? mq.addEventListener('change', placeRoute) : mq.addListener(placeRoute);

/* ---------- saklama ---------- */
var saveT;
function save() { clearTimeout(saveT); saveT = setTimeout(saveNow, 250); }
window.addEventListener('pagehide', saveNow); document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') saveNow(); });
function saveNow() { clearTimeout(saveT); try { localStorage.setItem(KEY, JSON.stringify({ cfg: { scenario: cfg.scenario, vehicles: cfg.vehicles, route: cfg.route, base: cfg.base }, ui: ui, raw: raw })); } catch (e) {} }
function load() {
  try {
    var d = JSON.parse(localStorage.getItem(KEY) || 'null'); if (!d) return; var def = E.defaultConfig();
    Object.keys(def.scenario).forEach(function (k) { var v = d.cfg.scenario[k]; if (typeof v === typeof def.scenario[k] && (typeof v !== 'number' || Number.isFinite(v))) cfg.scenario[k] = v; });
    KINDS.forEach(function (k) { Object.keys(def.vehicles[k]).forEach(function (f) { var v = d.cfg.vehicles[k][f]; if (typeof v === 'number' && Number.isFinite(v)) cfg.vehicles[k][f] = v; }); });
    var rt = d.cfg.route; if (rt) { if (rt.mode === 'route' || rt.mode === 'manual') cfg.route.mode = rt.mode; if (Number.isFinite(rt.manualKm)) cfg.route.manualKm = rt.manualKm;
      if (Array.isArray(rt.waypoints) && rt.waypoints.length <= 25 && rt.waypoints.every(function (w) { return w && typeof w.n === 'string' && Number.isFinite(w.lat) && Number.isFinite(w.lon) && Math.abs(w.lat) <= 90 && Math.abs(w.lon) <= 180; })) cfg.route.waypoints = rt.waypoints.map(function (w) { return { n: w.n, lat: w.lat, lon: w.lon }; }); }
    if (d.cfg.base === 'ice' || d.cfg.base === 'ev') cfg.base = d.cfg.base;
    if (d.ui) { if (['$', '€', '₺'].indexOf(d.ui.cur) > -1) ui.cur = d.ui.cur; if (typeof d.ui.routeOpen === 'boolean') ui.routeOpen = d.ui.routeOpen; if (Number.isInteger(d.ui.tip) && d.ui.tip >= 0 && d.ui.tip < D.TIPS.length) ui.tip = d.ui.tip; ui.tipDone = d.ui.tipDone === true;
      if (C.PARAMS.some(function (p) { return p.id === d.ui.param; })) ui.param = d.ui.param; if (C.METRICS.some(function (m) { return m.id === d.ui.metric; })) ui.metric = d.ui.metric; }
    if (d.raw && typeof d.raw === 'object') Object.keys(d.raw).forEach(function (id) { if (typeof d.raw[id] === 'string' && Number.isNaN(parse(d.raw[id]))) { raw[id] = d.raw[id]; var s = slider(id); if (s) s.paths.forEach(function (p) { setPath(p, NaN); }); else if (id.charAt(1) === '.') setPath(id, NaN); } });
  } catch (e) {}
}

/* ---------- başlat ---------- */
build(); load();
placeRoute(); renderWps(); renderTip(); onMapState('loading', ''); onTick({ has: false, playing: false, t: 0, duration: 0 });
startMap(); routeChanged();
window.__app = { cfg: function () { return cfg; }, routeInfo: function () { return routeInfo; } };
})();

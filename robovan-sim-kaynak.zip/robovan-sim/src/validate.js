'use strict';
/* Girdi doğrulama. Engelleyici hata (errors) varsa hesap yapılmaz; warnings bilgi içindir. */
const { isNum } = require('./geo');
const { KINDS } = require('./defaults');

const LABEL = {
  days: 'Çalışma günü', demand: 'Günlük toplam sefer', stops: 'Sefer başına durak', loadMin: 'Durak başına yükleme süresi',
  loadPct: 'Yük doluluğu', rate: 'Sermaye maliyeti', horizon: 'Değerlendirme süresi', fleet: 'Robovan sayısı',
  price: 'Araç alış bedeli', infra: 'Altyapı', residual: 'Kalıntı değer', life: 'Ekonomik ömür', eng: 'Mühendislik bedeli',
  l100: 'Yakıt tüketimi', fuel: 'Yakıt fiyatı', kwh100: 'Elektrik tüketimi', elec: 'Elektrik fiyatı', eff: 'Şarj verimi',
  chargeKw: 'Şarj gücü', range: 'Menzil', maint: 'Bakım', tire: 'Lastik', ins: 'Sigorta', tax: 'Vergi', lic: 'Lisans',
  driver: 'Sürücü maliyeti', operator: 'Operatör maliyeti', ratio: 'Operatör başına araç', shiftH: 'Vardiya süresi',
  payload: 'Azami yük', speed: 'Ortalama hız', hours: 'Günlük çalışma süresi',
};
/* [min, max, minDahilMi] — min dahil değilse (>) olmalı */
const SCENARIO_RULES = {
  days: [1, 366, true], demand: [0, 100000, true], stops: [0, 1000, true], loadMin: [0, 1440, true], loadPct: [0, 100, true],
  rate: [0, 100, true], horizon: [0, 50, true], fleet: [0, 100000, true],
};
const BIG = 1e9; /* makul üst sınır: taşmayı engeller */
const VEHICLE_RULES = {
  price: [0, BIG, true], infra: [0, BIG, true], residual: [0, 100, true], life: [0, 60, false], eng: [0, BIG, true],
  l100: [0, BIG, true], fuel: [0, BIG, true], kwh100: [0, BIG, true], elec: [0, BIG, true], eff: [0, 100, false],
  chargeKw: [0, BIG, false], range: [0, BIG, false], maint: [0, BIG, true], tire: [0, BIG, true],
  ins: [0, BIG, true], tax: [0, BIG, true], lic: [0, BIG, true], driver: [0, BIG, true], operator: [0, BIG, true],
  ratio: [0, BIG, false], shiftH: [0, 24, false], payload: [0, BIG, true], speed: [0, BIG, false], hours: [0, 24, false],
};
const REQUIRED = {
  robo: ['price', 'infra', 'residual', 'life', 'eng', 'kwh100', 'elec', 'eff', 'chargeKw', 'range', 'maint', 'tire', 'ins', 'tax', 'lic', 'operator', 'ratio', 'shiftH', 'payload', 'speed', 'hours'],
  ice: ['price', 'infra', 'residual', 'life', 'l100', 'fuel', 'maint', 'tire', 'ins', 'tax', 'driver', 'shiftH', 'payload', 'speed', 'hours'],
  ev: ['price', 'infra', 'residual', 'life', 'kwh100', 'elec', 'eff', 'chargeKw', 'range', 'maint', 'tire', 'ins', 'tax', 'driver', 'shiftH', 'payload', 'speed', 'hours'],
};

function checkField(value, rule, label, errors, scope) {
  if (!isNum(value)) { errors.push(`${scope}${label}: geçerli bir sayı girin.`); return; }
  const [min, max, inc] = rule;
  if (inc ? value < min : value <= min) errors.push(`${scope}${label}: ${inc ? min + ' veya daha büyük' : min + "'dan büyük"} olmalı.`);
  else if (value > max) errors.push(`${scope}${label}: en fazla ${max} olabilir.`);
}

function validateConfig(cfg) {
  const errors = [], warnings = [];
  const sc = cfg.scenario || {};
  Object.keys(SCENARIO_RULES).forEach((k) => checkField(sc[k], SCENARIO_RULES[k], LABEL[k], errors, ''));
  if (!isNum(sc.roadFactor) || sc.roadFactor < 1) errors.push('Yol katsayısı: en az 1 olmalı.');
  if (typeof sc.roundTrip !== 'boolean') errors.push('Sefer türü geçersiz.');
  if (isNum(sc.fleet) && sc.fleet !== Math.floor(sc.fleet)) errors.push('Robovan sayısı: tam sayı olmalı.');
  if (cfg.base !== 'ice' && cfg.base !== 'ev') errors.push('Karşılaştırma tabanı "ice" veya "ev" olmalı.');
  const names = { robo: 'Robovan', ice: 'Dizel van', ev: 'Elektrikli van' };
  KINDS.forEach((k) => {
    const v = (cfg.vehicles || {})[k];
    if (!v) { errors.push(`${names[k]}: araç bilgisi eksik.`); return; }
    REQUIRED[k].forEach((f) => checkField(v[f], VEHICLE_RULES[f], LABEL[f], errors, names[k] + ' · '));
    if (isNum(v.hours) && isNum(v.shiftH) && v.hours > 0 && v.shiftH > v.hours * 3) warnings.push(`${names[k]}: vardiya süresi günlük çalışma süresinden çok uzun görünüyor.`);
  });
  return { ok: errors.length === 0, errors, warnings };
}

module.exports = { validateConfig, LABEL };

'use strict';
/* Varsayılan senaryo ve araç değerleri. Şartname bölüm 4. YALNIZCA ÖRNEK değerlerdir. */
const SCENARIO_DEFAULTS = Object.freeze({
  days: 300, demand: 8, stops: 4, loadMin: 10, loadPct: 70, rate: 8, horizon: 5, fleet: 0,
  roadFactor: 1.3, roundTrip: true,
});

const ROUTE_DEFAULTS = Object.freeze({
  mode: 'route', manualKm: 4,
  waypoints: [
    { n: 'Gebze', lat: 40.8028, lon: 29.4307 },
    { n: 'İzmit (Kocaeli)', lat: 40.7654, lon: 29.9408 },
  ],
});

const VEHICLE_DEFAULTS = Object.freeze({
  robo: { price: 85000, infra: 5000, residual: 20, life: 8, eng: 15000, kwh100: 18, elec: 0.15, eff: 90, chargeKw: 22, range: 230, maint: 0.05, tire: 0.01, ins: 2500, tax: 0, lic: 250, operator: 1800, ratio: 5, shiftH: 8, payload: 1800, speed: 40, hours: 20 },
  ice: { price: 38000, infra: 0, residual: 25, life: 8, l100: 9, fuel: 1.5, maint: 0.08, tire: 0.02, ins: 2200, tax: 500, driver: 1500, shiftH: 8, payload: 1500, speed: 45, hours: 8 },
  ev: { price: 55000, infra: 3000, residual: 22, life: 8, kwh100: 20, elec: 0.15, eff: 90, chargeKw: 11, range: 200, maint: 0.05, tire: 0.02, ins: 2300, tax: 300, driver: 1500, shiftH: 8, payload: 1200, speed: 45, hours: 8 },
});

const KINDS = Object.freeze(['robo', 'ice', 'ev']);

function clone(o) { return JSON.parse(JSON.stringify(o)); }

function defaultConfig() {
  return { scenario: clone(SCENARIO_DEFAULTS), route: clone(ROUTE_DEFAULTS), vehicles: clone(VEHICLE_DEFAULTS), base: 'ice' };
}

module.exports = { SCENARIO_DEFAULTS, ROUTE_DEFAULTS, VEHICLE_DEFAULTS, KINDS, clone, defaultConfig };
